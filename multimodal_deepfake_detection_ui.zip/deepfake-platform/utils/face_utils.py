"""Face detection with OpenCV's bundled Haar cascade.

This is a BASELINE detector: fast and dependency-free, but it mainly finds
frontal faces and can miss side views, small faces or unusual lighting.
Both the image and video modules use it.
"""
from __future__ import annotations

import logging
import os
from typing import List, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

Box = Tuple[int, int, int, int]  # x, y, width, height

_cascade: Optional["cv2.CascadeClassifier"] = None
_cascade_checked = False


def _get_cascade():
    global _cascade, _cascade_checked
    if _cascade_checked:
        return _cascade
    _cascade_checked = True
    data_dir = getattr(getattr(cv2, "data", None), "haarcascades", None)
    if data_dir is None:
        data_dir = os.path.join(os.path.dirname(cv2.__file__), "data")
    path = os.path.join(data_dir, "haarcascade_frontalface_default.xml")
    if not os.path.exists(path):
        logger.warning("Haar cascade file not found at %s; face detection disabled.", path)
        return None
    cascade = cv2.CascadeClassifier(path)
    _cascade = None if cascade.empty() else cascade
    return _cascade


def face_detection_available() -> bool:
    return _get_cascade() is not None


def detect_faces(rgb: np.ndarray, min_size: int = 48, max_faces: int = 10) -> List[Box]:
    """Return face boxes (x, y, w, h) in the ORIGINAL image coordinates, largest first."""
    cascade = _get_cascade()
    if cascade is None:
        return []
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    h, w = gray.shape
    scale = 1.0
    max_side = 1280                      # shrink big images: much faster, same faces
    if max(h, w) > max_side:
        scale = max_side / max(h, w)
        gray = cv2.resize(gray, (int(w * scale), int(h * scale)))
    gray = cv2.equalizeHist(gray)
    found = cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(max(24, int(min_size * scale)), max(24, int(min_size * scale))),
    )
    boxes = [
        (int(x / scale), int(y / scale), int(fw / scale), int(fh / scale))
        for (x, y, fw, fh) in found
    ]
    boxes.sort(key=lambda b: b[2] * b[3], reverse=True)
    return boxes[:max_faces]


def crop_with_margin(rgb: np.ndarray, box: Box, margin: float = 0.25) -> np.ndarray:
    """Crop a face with some extra context around it (hair, chin, edges)."""
    x, y, w, h = box
    mx, my = int(w * margin), int(h * margin)
    x0, y0 = max(0, x - mx), max(0, y - my)
    x1, y1 = min(rgb.shape[1], x + w + mx), min(rgb.shape[0], y + h + my)
    return rgb[y0:y1, x0:x1]
