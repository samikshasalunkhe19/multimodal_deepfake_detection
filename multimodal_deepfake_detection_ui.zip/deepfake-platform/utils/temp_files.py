"""Safe temporary storage for uploads.

Uploaded files are written under a random name (never the user's filename),
analysed, and ALWAYS deleted afterwards, even if the analysis crashes.
Only the analysis RESULT is kept in the database.

Typical use:

    with secure_upload(file.file, file.filename, "image") as vf:
        result = analyze_image(vf.path)
    # file is already deleted here
"""
from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import BinaryIO, Iterator, Optional

from backend.config import settings
from utils.file_validation import (
    ValidatedFile,
    ValidationError,
    check_extension,
    validate_saved_file,
)

logger = logging.getLogger(__name__)

_CHUNK = 1024 * 1024  # read uploads 1 MB at a time


def save_upload(
    stream: BinaryIO,
    original_name: str,
    kind: str,
    temp_dir: Optional[Path] = None,
    max_bytes: Optional[int] = None,
) -> Path:
    """Copy an upload to the temp folder while enforcing the size limit.

    The size is checked WHILE reading, so a huge file is stopped early
    instead of being fully written to disk first.
    """
    ext = check_extension(original_name, kind)
    limit = max_bytes if max_bytes is not None else settings.max_bytes_for(kind)
    folder = Path(temp_dir) if temp_dir else settings.temp_dir
    folder.mkdir(parents=True, exist_ok=True)

    path = folder / f"{uuid.uuid4().hex}{ext}"
    total = 0
    try:
        with open(path, "wb") as out:
            while True:
                chunk = stream.read(_CHUNK)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise ValidationError(
                        f"File is too large. The limit for {kind}s is {limit // (1024 * 1024)} MB."
                    )
                out.write(chunk)
    except Exception:
        path.unlink(missing_ok=True)       # never leave a partial file behind
        raise
    return path


@contextmanager
def secure_upload(
    stream: BinaryIO,
    original_name: str,
    kind: str,
    temp_dir: Optional[Path] = None,
    max_bytes: Optional[int] = None,
    max_pixels: Optional[int] = None,
) -> Iterator[ValidatedFile]:
    """Save + validate an upload, hand it to the caller, then delete it."""
    path = save_upload(stream, original_name, kind, temp_dir, max_bytes)
    try:
        yield validate_saved_file(path, original_name, kind, max_pixels)
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            logger.warning("Could not delete temporary file %s", path)


def cleanup_stale_files(
    max_age_seconds: Optional[int] = None, temp_dir: Optional[Path] = None
) -> int:
    """Delete leftover temp files older than the limit (e.g. after a crash).

    Returns the number of files removed.
    """
    age = max_age_seconds if max_age_seconds is not None else settings.temp_file_max_age_seconds
    folder = Path(temp_dir) if temp_dir else settings.temp_dir
    if not folder.exists():
        return 0
    cutoff = time.time() - age
    removed = 0
    for item in folder.iterdir():
        try:
            if item.is_file() and item.stat().st_mtime < cutoff:
                item.unlink()
                removed += 1
        except OSError:
            logger.warning("Could not remove stale file %s", item)
    return removed
