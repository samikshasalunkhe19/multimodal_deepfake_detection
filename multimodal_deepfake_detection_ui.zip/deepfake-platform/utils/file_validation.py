"""Upload validation.

Checks, in order:
  1. filename is cleaned (no paths, no odd characters)
  2. extension is on the allow-list for the requested kind (image / video)
  3. file is not empty and not over the size limit (enforced in temp_files.py)
  4. the real file CONTENT (magic bytes) matches the extension
  5. images: must open as a real image and not be a decompression bomb

A file renamed from .exe to .png fails step 4, so extension checks alone
are never trusted.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PIL import Image

from backend.config import settings


class ValidationError(Exception):
    """Raised for any rejected upload. The message is safe to show to the user."""


@dataclass(frozen=True)
class ValidatedFile:
    path: Path          # where the temporary copy lives
    safe_name: str      # cleaned original name (for display / history only)
    extension: str      # e.g. ".png"
    kind: str           # "image" or "video"
    size_bytes: int


_SAFE_CHARS = re.compile(r"[^A-Za-z0-9._-]+")


def sanitize_filename(name: Optional[str]) -> str:
    """Return a harmless display name. The result is NEVER used as a disk path."""
    if not name:
        return "upload"
    name = name.replace("\\", "/")
    name = os.path.basename(name)          # drops ../../ style paths
    name = _SAFE_CHARS.sub("_", name).strip("._")
    if not name:
        return "upload"
    if len(name) > 100:
        stem, ext = os.path.splitext(name)
        name = stem[: 100 - len(ext)] + ext
    return name


def get_extension(name: str) -> str:
    return os.path.splitext(name)[1].lower()


def check_extension(original_name: str, kind: str) -> str:
    """Return the lower-case extension if allowed, otherwise raise."""
    ext = get_extension(sanitize_filename(original_name))
    allowed = settings.extensions_for(kind)
    if ext not in allowed:
        pretty = ", ".join(e.upper().lstrip(".") for e in allowed)
        raise ValidationError(f"Unsupported file type. Please upload one of: {pretty}.")
    return ext


# ---- magic-byte detection --------------------------------------------------

_JPEG = b"\xff\xd8\xff"
_PNG = b"\x89PNG\r\n\x1a\n"
# Old QuickTime .mov files may start with these atoms instead of 'ftyp'
_MOV_ATOMS = (b"ftyp", b"moov", b"mdat", b"wide", b"free", b"skip")


def detect_signature(head: bytes) -> Optional[str]:
    """Identify the container from the first bytes of a file."""
    if head.startswith(_JPEG):
        return "jpeg"
    if head.startswith(_PNG):
        return "png"
    if len(head) >= 12 and head[0:4] == b"RIFF" and head[8:12] == b"AVI ":
        return "avi"
    if len(head) >= 8 and head[4:8] in _MOV_ATOMS:
        return "mp4_mov"
    return None


_EXT_TO_SIGNATURE = {
    ".jpg": "jpeg",
    ".jpeg": "jpeg",
    ".png": "png",
    ".mp4": "mp4_mov",
    ".mov": "mp4_mov",
    ".avi": "avi",
}


def _check_image_content(path: Path, max_pixels: int) -> None:
    try:
        with Image.open(path) as img:
            width, height = img.size           # read from header, no full decode yet
            if width <= 0 or height <= 0:
                raise ValidationError("The image has invalid dimensions.")
            if width * height > max_pixels:
                raise ValidationError(
                    f"The image is too large ({width}x{height} pixels). "
                    "Please upload a smaller image."
                )
            img.verify()                       # detects truncated / corrupt data
    except ValidationError:
        raise
    except Exception:
        raise ValidationError("The file could not be read as a valid image.")


def validate_saved_file(
    path: Path,
    original_name: str,
    kind: str,
    max_pixels: Optional[int] = None,
) -> ValidatedFile:
    """Validate a file that has already been written to the temp folder."""
    path = Path(path)
    ext = check_extension(original_name, kind)

    size = path.stat().st_size
    if size == 0:
        raise ValidationError("The uploaded file is empty.")

    with open(path, "rb") as fh:
        head = fh.read(16)
    found = detect_signature(head)
    expected = _EXT_TO_SIGNATURE[ext]
    if found != expected:
        raise ValidationError(
            "The file content does not match its extension, so it was rejected."
        )

    if kind == "image":
        _check_image_content(path, max_pixels or settings.max_image_pixels)
    # Video: deep check (can OpenCV open it, duration limit) happens in Part 4.

    return ValidatedFile(
        path=path,
        safe_name=sanitize_filename(original_name),
        extension=ext,
        kind=kind,
        size_bytes=size,
    )
