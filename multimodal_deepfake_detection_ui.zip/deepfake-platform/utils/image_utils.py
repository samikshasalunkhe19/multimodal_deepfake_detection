"""Small image helpers shared by the image and video modules."""
from __future__ import annotations

import base64
import io
from pathlib import Path
from typing import Union

import numpy as np
from PIL import Image, ImageOps


def load_rgb(path: Union[str, Path], apply_orientation: bool = True) -> Image.Image:
    """Open an image as RGB.

    apply_orientation=True rotates the picture the way the camera intended
    (EXIF orientation). Error Level Analysis must use False, because rotating
    moves the JPEG 8x8 block grid.
    """
    with Image.open(path) as img:
        if apply_orientation:
            img = ImageOps.exif_transpose(img)
        return img.convert("RGB")


def ndarray_to_png_bytes(arr: np.ndarray) -> bytes:
    """Encode a uint8 array (H x W or H x W x 3) as PNG bytes."""
    if arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 255).astype(np.uint8)
    buf = io.BytesIO()
    Image.fromarray(arr).save(buf, format="PNG")
    return buf.getvalue()


def ndarray_to_base64_png(arr: np.ndarray) -> str:
    """PNG as a base64 string, so images can travel inside a JSON API response."""
    return base64.b64encode(ndarray_to_png_bytes(arr)).decode("ascii")
