"""Measure how well a module works on YOUR labelled data.

    python -m training.evaluate --modality image --data dataset/image
    python -m training.evaluate --modality video --data dataset/video --max-per-class 100

Folder layout:   <data>/real/*   and   <data>/fake/*

It runs the same analysers the app uses, so the numbers describe the whole pipeline
(model + heuristics + thresholds), and writes reports/eval_<modality>.json.

Only results marked `usable` are scored. Items the module could not judge are counted
and reported separately, never silently treated as correct or wrong.

HONESTY NOTES: a small test set gives a wide error margin; keep the test data separate from anything
a model was trained on; and results on one dataset do not carry over to other generators or sources.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score

from backend.config import settings
from utils.file_validation import ValidationError

EXTENSIONS = {
    "image": {".jpg", ".jpeg", ".png"},
    "video": {".mp4", ".avi", ".mov"},
}


def collect_files(root: Path, modality: str, max_per_class: Optional[int]) -> List[Tuple[Path, int]]:
    items: List[Tuple[Path, int]] = []
    for name, label in (("real", 0), ("fake", 1)):
        folder = root / name
        if not folder.is_dir():
            raise FileNotFoundError(f"Missing folder: {folder}")
        files = sorted(p for p in folder.iterdir() if p.suffix.lower() in EXTENSIONS[modality])
        items += [(p, label) for p in (files[:max_per_class] if max_per_class else files)]
    return items


def _analyzer(modality: str) -> Callable:
    if modality == "image":
        from modules.image_detection.analyzer import analyze_image
        return lambda p, clf: analyze_image(p, classifier=clf, want_heatmap=False)
    if modality == "video":
        from modules.video_detection.analyzer import analyze_video
        return lambda p, clf: analyze_video(p, classifier=clf)
    raise ValueError(modality)


def score_items(modality: str, items: Sequence[Tuple[Any, int]], classifier: Any = "auto") -> Dict[str, Any]:
    """items: (path_or_text, label). Returns raw scores for the usable items."""
    run = _analyzer(modality)

    y_true, y_score, unusable, errors = [], [], 0, 0
    for x, label in items:
        try:
            r = run(x, classifier)
        except ValidationError:
            errors += 1
            continue
        usable = getattr(r, "usable", getattr(r, "model_used", True))
        if not usable:
            unusable += 1
            continue
        y_true.append(label)
        y_score.append(r.risk_score)
    return {"y_true": y_true, "y_score": y_score, "unusable": unusable, "rejected": errors, "total": len(items)}


def summarise(raw: Dict[str, Any], threshold: float = 50.0) -> Dict[str, Any]:
    y, s = raw["y_true"], raw["y_score"]
    out: Dict[str, Any] = {"total": raw["total"], "scored": len(y), "unusable": raw["unusable"],
                           "rejected_by_validation": raw["rejected"], "threshold": threshold}
    if len(y) == 0 or len(set(y)) < 2:
        out["note"] = ("Not enough usable results from both classes to compute metrics. "
                       "Is a trained model configured for this modality?")
        return out
    pred = [1 if v >= threshold else 0 for v in s]
    out.update({
        "accuracy": round(accuracy_score(y, pred), 4),
        "precision": round(precision_score(y, pred, zero_division=0), 4),
        "recall": round(recall_score(y, pred, zero_division=0), 4),
        "f1": round(f1_score(y, pred, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y, s), 4),
        "confusion_matrix [[TN FP] [FN TP]]": confusion_matrix(y, pred).tolist(),
        "n_real": y.count(0), "n_fake": y.count(1),
    })
    if len(y) < 200:
        out["warning"] = "Fewer than 200 scored items: treat these numbers as rough, with a wide margin of error."
    return out


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Evaluate a detection module on labelled data.")
    ap.add_argument("--modality", required=True, choices=["image", "video"])
    ap.add_argument("--data", required=True, type=Path)
    ap.add_argument("--threshold", type=float, default=50.0, help="risk score at or above this counts as 'fake'")
    ap.add_argument("--max-per-class", type=int, default=None)
    args = ap.parse_args(argv)

    try:
        items = collect_files(args.data, args.modality, args.max_per_class)
    except (FileNotFoundError, ValueError, OSError) as exc:
        print(f"Error: {exc}")
        return 1

    summary = summarise(score_items(args.modality, items), args.threshold)
    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    out = settings.reports_dir / f"eval_{args.modality}.json"
    out.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    print(f"\nSaved to {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
