"""Video analysis pipeline.

    analyze_video(path)  ->  VideoAnalysis  ->  .to_dict()   (JSON-safe)

Steps:
  1. probe the file (reject broken / too long / too large videos)
  2. choose frames evenly across the video (default ~1 per second, max 60)
  3. read each frame, find the largest face, crop it
  4. score the face crop with the same trained classifier as the image module
  5. aggregate frame scores into a video score (top-k + temporal consistency)
  6. report suspicious frames with timestamps, plus a score-over-time series

Frames without a detectable face are skipped (not scored). If fewer than
MIN_SCORED_FRAMES frames can be scored, the result is marked NOT usable and
the fusion engine will ignore this module.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import cv2
import numpy as np
from PIL import Image

from modules.image_detection import scoring
from modules.image_detection.detector import get_classifier
from modules.video_detection.aggregator import TOP_FRACTION, aggregate_scores, video_confidence
from modules.video_detection.frame_extractor import (
    choose_frame_indices,
    format_timestamp,
    iter_sampled_frames,
    probe_video,
)
from utils.face_utils import crop_with_margin, detect_faces, face_detection_available
from utils.image_utils import ndarray_to_base64_png

logger = logging.getLogger(__name__)

MIN_FACE_CROP = 32          # pixels; smaller crops carry too little detail
MIN_SCORED_FRAMES = 3       # below this the result is "not enough evidence"
TOP_FRAMES_SHOWN = 6
THUMB_SIDE = 160


@dataclass
class FrameResult:
    index: int
    timestamp: float
    face_found: bool
    p_fake: Optional[float] = None
    thumb: Optional[np.ndarray] = field(default=None, repr=False)


@dataclass
class VideoAnalysis:
    result_label: str
    risk_score: float
    risk_level: str
    confidence: float
    explanation: str
    evidence: Dict[str, Any]
    limitations: List[str]
    model_used: bool
    usable: bool
    top_frames: List[Dict[str, Any]] = field(default_factory=list)
    timeline: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self, include_images: bool = True) -> dict:
        frames = []
        for f in self.top_frames:
            item = {k: v for k, v in f.items() if k != "thumb"}
            if include_images:
                item["thumbnail_png_b64"] = (
                    ndarray_to_base64_png(f["thumb"]) if f.get("thumb") is not None else None
                )
            frames.append(item)
        return {
            "modality": "video",
            "result_label": self.result_label,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "confidence": self.confidence,
            "p_fake": self.evidence.get("aggregate", {}).get("video_p_fake"),
            "explanation": self.explanation,
            "evidence": self.evidence,
            "suspicious_frames": frames,
            "timeline": self.timeline,
            "limitations": self.limitations,
            "model_used": self.model_used,
            "usable": self.usable,
        }


def _thumbnail(rgb: np.ndarray) -> np.ndarray:
    h, w = rgb.shape[:2]
    scale = THUMB_SIDE / max(h, w)
    if scale >= 1.0:
        return rgb.copy()
    return cv2.resize(rgb, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA)


def _label_for(level: str) -> str:
    return {
        "High": "Likely manipulated (deepfake) video",
        "Medium": "Uncertain - possible manipulation",
        "Low": "No strong signs of manipulation detected",
    }[level]


def analyze_video(
    path: Union[str, Path],
    classifier: Any = "auto",
    progress_cb: Optional[Callable[[int, int], None]] = None,
    face_detector: Any = "auto",
    target_fps: Optional[float] = None,
    max_frames: Optional[int] = None,
) -> VideoAnalysis:
    """Analyse one video file.

    classifier:    "auto" -> configured Hugging Face model; None -> skip; or any object with .predict(PIL)
    face_detector: "auto" -> OpenCV Haar cascade; None -> score whole frames; or callable(rgb) -> boxes
    progress_cb:   called as progress_cb(frames_done, frames_total) for progress bars
    Raises ValidationError (from probe_video) for unreadable / too long / too large videos.
    """
    path = Path(path)
    limitations: List[str] = []
    info = probe_video(path)

    clf, clf_error = None, None
    if isinstance(classifier, str) and classifier == "auto":
        clf, clf_error = get_classifier()
    elif classifier is None:
        clf_error = "The trained classifier was turned off for this run."
    else:
        clf = classifier

    if isinstance(face_detector, str) and face_detector == "auto":
        face_fn = detect_faces if face_detection_available() else None
    else:
        face_fn = face_detector
    if face_fn is None:
        limitations.append(
            "Face detection is unavailable, so whole frames were scored instead of face crops. "
            "Face-focused detectors may be less reliable this way."
        )

    indices = choose_frame_indices(info.frame_count, info.fps, target_fps, max_frames)
    frames: List[FrameResult] = []
    predict_errors = 0

    if clf is not None:
        for done, (idx, rgb) in enumerate(iter_sampled_frames(path, indices), start=1):
            ts = idx / info.fps
            image = None
            if face_fn is None:
                image = Image.fromarray(rgb)
            else:
                boxes = face_fn(rgb)
                if boxes:
                    crop = crop_with_margin(rgb, boxes[0])
                    if min(crop.shape[:2]) >= MIN_FACE_CROP:
                        image = Image.fromarray(crop)
            if image is None:
                frames.append(FrameResult(idx, ts, face_found=False))
            else:
                try:
                    out = clf.predict(image)
                    frames.append(FrameResult(idx, ts, True, out.p_fake, _thumbnail(np.asarray(image))))
                except Exception as exc:
                    predict_errors += 1
                    logger.warning("Frame %s could not be scored: %s", idx, exc)
                    frames.append(FrameResult(idx, ts, True))
            if progress_cb:
                progress_cb(done, len(indices))
        if progress_cb:
            progress_cb(len(indices), len(indices))

    scored = [f for f in frames if f.p_fake is not None]
    faces_found = sum(1 for f in frames if f.face_found)
    model_used = clf is not None and len(scored) > 0

    evidence: Dict[str, Any] = {
        "video_info": info.to_dict(),
        "frames_sampled": len(frames),
        "frames_with_faces": faces_found,
        "frames_scored": len(scored),
        "scoring_mode": "face crops" if face_fn is not None else "whole frames",
    }
    timeline = [
        {"t": round(f.timestamp, 2), "p_fake": None if f.p_fake is None else round(f.p_fake, 4)}
        for f in frames
    ]
    if predict_errors:
        limitations.append(f"{predict_errors} frame(s) could not be scored because the classifier raised an error.")

    # ---- not enough evidence -> unusable, neutral result ----
    if len(scored) < MIN_SCORED_FRAMES:
        if clf is None:
            reason = (clf_error or "No trained classifier was used.")
            label = "Inconclusive (trained model not available)"
        else:
            reason = (
                f"Only {len(scored)} frame(s) could be scored (at least {MIN_SCORED_FRAMES} needed). "
                "Faces may be missing, too small or hidden."
            )
            label = "Inconclusive (not enough usable frames)"
        limitations.append(reason + " This module's result is not used as evidence.")
        limitations.append("Detectors can be wrong. This is a risk estimate, not proof.")
        return VideoAnalysis(
            result_label=label,
            risk_score=50.0,
            risk_level="Medium",
            confidence=0.0,
            explanation=f"No reliable video-level score could be produced. {reason}",
            evidence=evidence,
            limitations=limitations,
            model_used=model_used,
            usable=False,
            timeline=timeline,
        )

    # ---- aggregate ----
    agg = aggregate_scores([f.timestamp for f in scored], [f.p_fake for f in scored])
    score = round(100.0 * agg.video_p, 1)
    level = scoring.risk_level(score)
    confidence = video_confidence(agg.video_p, agg.n_frames, agg.jitter)
    evidence["aggregate"] = agg.to_dict()
    evidence["model_id"] = getattr(clf, "model_id", "custom")

    ranked = sorted(scored, key=lambda f: f.p_fake, reverse=True)[:TOP_FRAMES_SHOWN]
    top_frames = [
        {
            "frame_index": f.index,
            "timestamp_s": round(f.timestamp, 2),
            "timestamp": format_timestamp(f.timestamp),
            "p_fake": round(f.p_fake, 4),
            "thumb": f.thumb,
        }
        for f in ranked
    ]

    # ---- limitations & explanation ----
    if len(frames) > len(scored):
        limitations.append(
            f"{len(frames) - len(scored)} of {len(frames)} sampled frames had no usable face and were skipped."
        )
    if agg.n_frames < 10:
        limitations.append("Few frames were scored, so the video-level result is less reliable.")
    limitations.append(
        "Frames are analysed independently (about 1 per second), so subtle motion artefacts between "
        "frames are not modelled. The classifier was not necessarily trained on this kind of video."
    )
    limitations.append(
        "Detectors can be wrong, especially on manipulation methods newer than their training data or "
        "on heavily compressed video. This is a risk estimate, not proof."
    )

    parts = [
        f"{agg.n_frames} frames were scored from a {info.duration_s:.0f}-second video. "
        f"Average fake likelihood {agg.mean_p * 100:.0f}%; the most suspicious {TOP_FRACTION * 100:.0f}% of frames "
        f"average {agg.top_k_mean_p * 100:.0f}%."
    ]
    if agg.segments:
        s = agg.segments[0]
        parts.append(
            f"{len(agg.segments)} suspicious segment(s) found, e.g. {format_timestamp(s.start_s)}"
            f"-{format_timestamp(s.end_s)} (peak {s.max_p * 100:.0f}%)."
        )
    elif agg.fraction_suspicious > 0:
        parts.append("Some individual frames scored high, but not for consecutive frames, which looks more like noise.")

    return VideoAnalysis(
        result_label=_label_for(level),
        risk_score=score,
        risk_level=level,
        confidence=confidence,
        explanation=" ".join(parts),
        evidence=evidence,
        limitations=limitations,
        model_used=True,
        usable=True,
        top_frames=top_frames,
        timeline=timeline,
    )
