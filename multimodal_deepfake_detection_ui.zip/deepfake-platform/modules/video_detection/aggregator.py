"""Turn many frame-level scores into ONE video-level result.

Why not just average?
  A video can be manipulated for only a few seconds. A plain mean of all frames
  dilutes that short segment and the video looks "mostly real".

Why not just take the maximum?
  Any frame classifier makes occasional random mistakes. The single highest
  score of 30 frames is very often a mistake on a real video.

Our compromise (documented priors, tunable, not fitted on data):
    top_k_mean = average of the most suspicious 25% of frames
    video_p    = 0.5 * mean + 0.5 * top_k_mean

Temporal consistency (is the suspicion persistent or just flicker?):
  * longest run  - the longest streak of consecutive suspicious frames
  * jitter       - average jump between neighbouring frame scores
  * segments     - runs of >= 2 consecutive suspicious frames, with timestamps
A real fake face usually keeps its artefacts for a stretch of frames, while
classifier noise tends to flicker. This is a heuristic and the report says so.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Sequence

import numpy as np

TOP_FRACTION = 0.25
BLEND = 0.5            # weight of top_k_mean in video_p (the rest is the plain mean)
THRESHOLD = 0.5        # frame counts as "suspicious" at or above this p_fake
MIN_SEGMENT_FRAMES = 2


@dataclass
class Segment:
    start_s: float
    end_s: float
    n_frames: int
    max_p: float

    def to_dict(self) -> dict:
        return {
            "start_s": round(self.start_s, 2),
            "end_s": round(self.end_s, 2),
            "n_frames": self.n_frames,
            "max_p_fake": round(self.max_p, 4),
        }


@dataclass
class VideoAggregate:
    n_frames: int
    mean_p: float
    top_k_mean_p: float
    video_p: float
    std_p: float
    jitter: float
    fraction_suspicious: float
    longest_run: int
    segments: List[Segment] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "frames_scored": self.n_frames,
            "mean_p_fake": round(self.mean_p, 4),
            "top_k_mean_p_fake": round(self.top_k_mean_p, 4),
            "video_p_fake": round(self.video_p, 4),
            "std_p_fake": round(self.std_p, 4),
            "jitter": round(self.jitter, 4),
            "fraction_suspicious": round(self.fraction_suspicious, 4),
            "longest_suspicious_run_frames": self.longest_run,
            "segments": [s.to_dict() for s in self.segments],
        }


def _runs(flags: Sequence[bool]) -> List[tuple]:
    """Start/end index (inclusive) of each streak of True values."""
    runs, start = [], None
    for i, f in enumerate(flags):
        if f and start is None:
            start = i
        elif not f and start is not None:
            runs.append((start, i - 1))
            start = None
    if start is not None:
        runs.append((start, len(flags) - 1))
    return runs


def aggregate_scores(
    timestamps: Sequence[float],
    probs: Sequence[float],
    threshold: float = THRESHOLD,
    top_fraction: float = TOP_FRACTION,
    blend: float = BLEND,
    min_segment_frames: int = MIN_SEGMENT_FRAMES,
) -> VideoAggregate:
    """timestamps and probs are parallel lists for the frames that were scored, in time order."""
    if len(timestamps) != len(probs):
        raise ValueError("timestamps and probs must have the same length")
    if len(probs) == 0:
        raise ValueError("Cannot aggregate zero frames")

    p = np.asarray(probs, dtype=float)
    n = len(p)
    k = max(1, math.ceil(top_fraction * n))
    top_k_mean = float(np.sort(p)[-k:].mean())
    mean_p = float(p.mean())
    video_p = float(min(max((1 - blend) * mean_p + blend * top_k_mean, 0.0), 1.0))

    jitter = float(np.abs(np.diff(p)).mean()) if n > 1 else 0.0
    flags = [bool(x >= threshold) for x in p]
    runs = _runs(flags)
    longest = max((e - s + 1 for s, e in runs), default=0)

    segments = [
        Segment(
            start_s=float(timestamps[s]),
            end_s=float(timestamps[e]),
            n_frames=e - s + 1,
            max_p=float(p[s:e + 1].max()),
        )
        for s, e in runs
        if e - s + 1 >= min_segment_frames
    ]

    return VideoAggregate(
        n_frames=n,
        mean_p=mean_p,
        top_k_mean_p=top_k_mean,
        video_p=video_p,
        std_p=float(p.std()),
        jitter=jitter,
        fraction_suspicious=sum(flags) / n,
        longest_run=longest,
        segments=segments,
    )


def video_confidence(video_p: float, n_scored: int, jitter: float) -> float:
    """How decisive the evidence is (0..1). NOT a calibrated probability.

    = distance from 50/50, reduced when few frames were scored (little
    evidence) and when scores jump around a lot (unstable model output).
    """
    decisiveness = abs(2.0 * video_p - 1.0)
    coverage = 0.5 if n_scored < 5 else 0.75 if n_scored < 10 else 1.0
    stability = 1.0 - min(0.4, jitter)
    return round(min(max(decisiveness * coverage * stability, 0.0), 1.0), 3)
