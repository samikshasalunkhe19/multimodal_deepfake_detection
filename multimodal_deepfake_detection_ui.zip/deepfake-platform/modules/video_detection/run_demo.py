"""Command-line demo for the video module (no backend or UI needed).

    python -m modules.video_detection.run_demo --video path\\to\\clip.mp4
    python -m modules.video_detection.run_demo --video clip.mp4 --no-model --max-frames 20

Saves a score-over-time chart and the most suspicious frames to reports/demo/.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from backend.config import settings
from modules.video_detection.analyzer import analyze_video
from utils.file_validation import ValidationError, validate_saved_file
from utils.image_utils import ndarray_to_png_bytes


def save_timeline_png(timeline: list, out_path: Path, threshold: float = 0.5) -> bool:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    pts = [(p["t"], p["p_fake"]) for p in timeline if p["p_fake"] is not None]
    if not pts:
        return False
    t, p = zip(*pts)
    fig, ax = plt.subplots(figsize=(8, 3.2))
    ax.plot(t, p, marker="o", linewidth=1.5)
    ax.axhline(threshold, linestyle="--", linewidth=1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("p(fake) per frame")
    ax.set_title("Frame-level fake likelihood over time")
    fig.tight_layout()
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyse one video with the video module.")
    parser.add_argument("--video", required=True, help="Path to an MP4 / AVI / MOV file")
    parser.add_argument("--no-model", action="store_true", help="Skip the trained classifier")
    parser.add_argument("--fps", type=float, default=None, help="Frames to analyse per second (default 1)")
    parser.add_argument("--max-frames", type=int, default=None, help="Maximum frames to analyse (default 60)")
    args = parser.parse_args()

    path = Path(args.video)
    if not path.is_file():
        print(f"File not found: {path}")
        return 1
    try:
        validate_saved_file(path, path.name, "video")
        result = analyze_video(
            path,
            classifier=None if args.no_model else "auto",
            progress_cb=lambda done, total: print(f"\rAnalysing frames: {done}/{total}", end="", flush=True),
            target_fps=args.fps,
            max_frames=args.max_frames,
        )
    except ValidationError as exc:
        print(f"Rejected: {exc}")
        return 1
    print()

    out_dir = settings.reports_dir / "demo"
    out_dir.mkdir(parents=True, exist_ok=True)
    if save_timeline_png(result.timeline, out_dir / f"{path.stem}_timeline.png"):
        print(f"Timeline chart: {out_dir / (path.stem + '_timeline.png')}")
    for i, f in enumerate(result.top_frames, start=1):
        if f.get("thumb") is not None:
            (out_dir / f"{path.stem}_suspicious_{i}.png").write_bytes(ndarray_to_png_bytes(f["thumb"]))

    print(json.dumps(result.to_dict(include_images=False), indent=2))
    print(f"\nFiles saved in: {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
