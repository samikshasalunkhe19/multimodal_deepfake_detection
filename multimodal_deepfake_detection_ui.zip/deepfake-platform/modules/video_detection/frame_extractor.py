"""Video probing and frame sampling with OpenCV.

Design choices (and why):
  * probe_video() opens the file first and rejects broken, empty, over-long or
    oversized videos BEFORE any heavy work. Decoding untrusted video is an
    attack surface, so we also keep OpenCV up to date and limit size/duration.
  * Frames are read one at a time (a generator), never all loaded into memory.
    60 full-HD frames would already be ~370 MB.
  * Frames are chosen evenly across the WHOLE video, so a manipulated part at
    the end is not missed just because the video is long.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional, Sequence, Tuple, Union

import cv2
import numpy as np

from backend.config import settings
from utils.file_validation import ValidationError


@dataclass(frozen=True)
class VideoInfo:
    fps: float
    frame_count: int
    width: int
    height: int
    duration_s: float

    def to_dict(self) -> dict:
        return {
            "fps": round(self.fps, 3),
            "frame_count": self.frame_count,
            "width": self.width,
            "height": self.height,
            "duration_s": round(self.duration_s, 2),
        }


def probe_video(path: Union[str, Path], max_seconds: Optional[int] = None) -> VideoInfo:
    """Open the video and read its basic properties, or raise ValidationError."""
    limit = max_seconds if max_seconds is not None else settings.video_max_seconds
    cap = cv2.VideoCapture(str(path))
    try:
        if not cap.isOpened():
            raise ValidationError(
                "The video could not be opened. It may be corrupt or use an unsupported codec."
            )
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    finally:
        cap.release()

    if not math.isfinite(fps) or fps <= 0 or fps > 1000:
        raise ValidationError("The video's frame rate could not be read.")
    if frame_count <= 0:
        raise ValidationError("The video contains no readable frames.")
    if width <= 0 or height <= 0:
        raise ValidationError("The video has invalid dimensions.")
    if max(width, height) > settings.video_max_side_px:
        raise ValidationError(
            f"The video resolution ({width}x{height}) is too high. "
            f"Maximum side length is {settings.video_max_side_px} pixels."
        )
    duration = frame_count / fps
    if duration > limit:
        raise ValidationError(
            f"The video is too long ({duration:.0f} s). The limit is {limit} seconds."
        )
    return VideoInfo(fps=fps, frame_count=frame_count, width=width, height=height, duration_s=duration)


def choose_frame_indices(
    frame_count: int,
    fps: float,
    target_fps: Optional[float] = None,
    max_frames: Optional[int] = None,
) -> List[int]:
    """Pick which frame numbers to analyse: ~target_fps per second, at most max_frames, evenly spread."""
    target = target_fps if target_fps is not None else settings.video_sample_fps
    cap = max_frames if max_frames is not None else settings.video_max_frames
    if frame_count <= 0 or fps <= 0 or target <= 0 or cap <= 0:
        return []
    step = max(1, int(round(fps / target)))
    indices = list(range(0, frame_count, step))
    if len(indices) > cap:
        positions = np.linspace(0, len(indices) - 1, cap).round().astype(int)
        indices = [indices[p] for p in sorted(set(positions.tolist()))]
    return indices


def iter_sampled_frames(
    path: Union[str, Path], indices: Sequence[int]
) -> Iterator[Tuple[int, np.ndarray]]:
    """Yield (frame_index, RGB frame) for the wanted indices, in order.

    Uses grab() to skip unwanted frames cheaply and only decodes the wanted
    ones. Stops quietly if the file ends earlier than its header claimed.
    """
    wanted = set(int(i) for i in indices)
    if not wanted:
        return
    last = max(wanted)
    cap = cv2.VideoCapture(str(path))
    try:
        idx = 0
        while idx <= last:
            if not cap.grab():
                break
            if idx in wanted:
                ok, bgr = cap.retrieve()
                if ok and bgr is not None:
                    yield idx, cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            idx += 1
    finally:
        cap.release()


def format_timestamp(seconds: float) -> str:
    """12.34 -> '0:12.3'"""
    seconds = max(0.0, float(seconds))
    minutes = int(seconds // 60)
    return f"{minutes}:{seconds - 60 * minutes:04.1f}"
