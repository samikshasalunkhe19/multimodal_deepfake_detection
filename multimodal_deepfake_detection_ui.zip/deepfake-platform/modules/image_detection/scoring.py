"""How the image module combines its three signals into one risk score.

Method: weighted sum in LOGIT space (log-odds), then back to a probability.

    z = logit(p_classifier) + ela_term + metadata_term
    risk = 100 * sigmoid(z)

Why logit space and not a plain average of percentages?
  Probabilities are bounded (0..1) and not additive. Evidence adds up
  naturally as log-odds, which is exactly what logistic regression does.

Why the weights are small for ELA and metadata:
  The classifier is the only trained signal. ELA and metadata are weak
  heuristics, so they may only NUDGE the result. The numbers below are
  documented PRIORS chosen by us, not fitted on data. Part 7 shows how to fit
  them on a validation set with logistic regression.
"""
from __future__ import annotations

import math
from typing import List, Optional, Tuple

from backend.config import settings

P_MIN, P_MAX = 0.01, 0.99          # keeps logit(p) finite and avoids 0% / 100%

# --- documented priors (logit units) ---
ELA_MAX_NUDGE = 0.5                # ela_score 0..1  ->  -0.5 .. +0.5
META_AI_TAG = 2.0                  # metadata explicitly names an AI generator
META_EDITOR_TAG = 0.3              # editing software named (very common, weak)
META_NO_EXIF_JPEG = 0.2            # JPEG without EXIF (often just stripped by an app)


def logit(p: float) -> float:
    p = min(max(p, P_MIN), P_MAX)
    return math.log(p / (1.0 - p))


def sigmoid(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


def ela_term(ela_score: Optional[float]) -> float:
    if ela_score is None:
        return 0.0
    return (min(max(ela_score, 0.0), 1.0) - 0.5) * 2 * ELA_MAX_NUDGE


def metadata_term(meta) -> Tuple[float, List[str]]:
    z, reasons = 0.0, []
    if meta.ai_indicators:
        z += META_AI_TAG
        reasons.append("metadata names an AI image tool")
    if meta.editing_software:
        z += META_EDITOR_TAG
        reasons.append("metadata names editing software")
    if meta.format == "JPEG" and not meta.has_exif:
        z += META_NO_EXIF_JPEG
        reasons.append("JPEG has no EXIF data")
    return z, reasons


def combine_signals(p_classifier: Optional[float], ela_score: Optional[float], meta) -> dict:
    """Return the 0-100 risk score and the pieces it was built from."""
    base = logit(p_classifier) if p_classifier is not None else 0.0   # 0.0 = "no opinion"
    e = ela_term(ela_score)
    m, meta_reasons = metadata_term(meta)
    z = base + e + m
    return {
        "risk_score": round(100.0 * sigmoid(z), 1),
        "logit_total": z,
        "terms": {"classifier": base, "ela": e, "metadata": m},
        "metadata_reasons": meta_reasons,
    }


def risk_level(score: float) -> str:
    if score < settings.risk_low_max:
        return "Low"
    if score > settings.risk_high_min:
        return "High"
    return "Medium"


def confidence_from(p_classifier: Optional[float], width: int, height: int) -> float:
    """How decisive the evidence is (0..1). NOT a calibrated probability.

    = distance of the classifier from 50/50, reduced for small images (less
    detail for any detector) and capped low when no trained model was used.
    """
    if p_classifier is None:
        return 0.1
    decisiveness = abs(2.0 * p_classifier - 1.0)
    smallest = min(width, height)
    quality = 0.6 if smallest < 128 else 0.8 if smallest < 256 else 1.0
    return round(min(max(decisiveness * quality, 0.0), 1.0), 3)
