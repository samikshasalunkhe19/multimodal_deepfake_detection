"""Error Level Analysis (ELA) - a classical, explainable BASELINE technique.

Idea (simple version for the viva):
  A JPEG loses a little detail every time it is saved. If we re-save the image
  once at a known quality and subtract it from the original, parts that were
  already saved many times change very little, while parts that were pasted in
  or edited later often change more. The difference image highlights this.

Honest limits:
  * It only works on JPEG files (PNG is lossless, so there is nothing to compare).
  * Sharp edges and detailed textures also show high error, so a bright ELA
    map is NOT proof of editing.
  * The 0-1 score below is an uncalibrated heuristic. It is shown as supporting
    evidence only and is never treated as a trained detector.
"""
from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import numpy as np
from PIL import Image

from backend.config import settings


@dataclass
class ELAResult:
    applicable: bool
    note: str
    score: Optional[float] = None        # 0..1 heuristic, higher = more uneven error levels
    spread: Optional[float] = None       # raw statistic behind the score
    mean_error: Optional[float] = None   # average pixel error (0..255 scale)
    ela_map: Optional[np.ndarray] = None  # uint8 H x W x 3 visualisation


def _not_applicable(note: str) -> ELAResult:
    return ELAResult(applicable=False, note=note)


def compute_ela(
    path: Union[str, Path],
    quality: int = 90,
    block: int = 16,
    max_pixels: Optional[int] = None,
) -> ELAResult:
    max_pixels = max_pixels or settings.ela_max_pixels

    with Image.open(path) as img:
        if img.format != "JPEG":
            return _not_applicable(
                "ELA only works on JPEG files. PNG is lossless, so there is no "
                "compression history to analyse."
            )
        width, height = img.size
        if width * height > max_pixels:
            return _not_applicable("Image is too large for ELA; this check was skipped.")
        original = img.convert("RGB")   # NOT rotated: rotation would shift the JPEG block grid

    buf = io.BytesIO()
    original.save(buf, format="JPEG", quality=quality)
    buf.seek(0)
    with Image.open(buf) as resaved_img:
        resaved = resaved_img.convert("RGB")

    a = np.asarray(original, dtype=np.int16)
    b = np.asarray(resaved, dtype=np.int16)
    diff = np.abs(a - b)                      # per-channel error
    err = diff.mean(axis=2)                   # one error value per pixel

    h2 = (err.shape[0] // block) * block
    w2 = (err.shape[1] // block) * block
    if h2 < block * 4 or w2 < block * 4:
        return _not_applicable("Image is too small for a meaningful ELA.")

    # Average the error inside each 16x16 block, then compare the "hot" blocks
    # (95th percentile) with a typical block (median).
    blocks = err[:h2, :w2].reshape(h2 // block, block, w2 // block, block).mean(axis=(1, 3))
    median = float(np.median(blocks))
    p95 = float(np.percentile(blocks, 95))
    spread = (p95 - median) / (median + 1.0)
    score = spread / (spread + 1.0)           # squashes 0..inf into 0..1 (illustrative scaling)

    scale = 255.0 / max(float(np.percentile(err, 99.5)), 1.0)
    ela_map = np.clip(diff * scale, 0, 255).astype(np.uint8)

    return ELAResult(
        applicable=True,
        note="Heuristic baseline; bright regions only mean 'different compression error'.",
        score=float(score),
        spread=float(spread),
        mean_error=float(err.mean()),
        ela_map=ela_map,
    )
