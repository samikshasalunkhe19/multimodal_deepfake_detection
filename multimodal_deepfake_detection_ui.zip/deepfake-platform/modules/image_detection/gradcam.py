"""Grad-CAM heatmap: which image regions pushed the model towards 'fake'.

Simple explanation (for the viva):
  We take the model's score for the 'fake' class and ask, "if each part of the
  last layer changed a little, how much would that score change?". Parts with
  a big effect are drawn in red/yellow.

Honest limits:
  * It shows where the MODEL looked, not where the image was edited.
  * Currently supported for Vision Transformer (ViT) models only. For other
    architectures the function returns (None, reason) and the rest of the
    pipeline keeps working.
"""
from __future__ import annotations

import logging
import math
from typing import Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

_MAX_SIDE = 512


def _vit_target_layer(model):
    """Last transformer block's first LayerNorm (the layer used in the pytorch-grad-cam ViT recipe)."""
    vit = getattr(model, "vit", None)
    if vit is None:
        return None
    try:
        return vit.encoder.layer[-1].layernorm_before
    except (AttributeError, IndexError):
        return None


def compute_gradcam(classifier, pil_image, target_index: int) -> Tuple[Optional[np.ndarray], Optional[str]]:
    """Return (overlay_rgb_uint8, None) on success or (None, reason) on failure."""
    try:
        import torch
        from pytorch_grad_cam import GradCAM
        from pytorch_grad_cam.utils.image import show_cam_on_image
        from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
    except ImportError:
        return None, "Grad-CAM skipped: the 'grad-cam' package is not installed."

    model = getattr(classifier, "model", None)
    if model is None:
        return None, "Grad-CAM skipped: this classifier does not expose a PyTorch model."
    layer = _vit_target_layer(model)
    if layer is None:
        return None, "Grad-CAM is only implemented for ViT models; skipped for this architecture."

    class _Logits(torch.nn.Module):
        """pytorch-grad-cam expects a module that returns a plain tensor."""
        def __init__(self, inner):
            super().__init__()
            self.inner = inner

        def forward(self, x):
            return self.inner(pixel_values=x).logits

    def reshape_transform(tensor):
        tokens = tensor[:, 1:, :]                      # drop the [CLS] token
        side = int(math.sqrt(tokens.size(1)))
        grid = tokens.reshape(tokens.size(0), side, side, tokens.size(2))
        return grid.permute(0, 3, 1, 2)                # (B, C, H, W)

    try:
        x = classifier.preprocess(pil_image)
        cam = GradCAM(model=_Logits(model), target_layers=[layer], reshape_transform=reshape_transform)
        with torch.enable_grad():
            gray = cam(input_tensor=x, targets=[ClassifierOutputTarget(int(target_index))])[0]

        base = pil_image.convert("RGB")
        scale = min(1.0, _MAX_SIDE / max(base.size))
        if scale < 1.0:
            base = base.resize((max(1, int(base.width * scale)), max(1, int(base.height * scale))))
        base_f = np.asarray(base, dtype=np.float32) / 255.0
        gray = cv2.resize(gray.astype(np.float32), (base_f.shape[1], base_f.shape[0]))
        return show_cam_on_image(base_f, gray, use_rgb=True), None
    except Exception as exc:
        logger.warning("Grad-CAM failed: %s", exc)
        return None, f"Grad-CAM failed: {exc}"
