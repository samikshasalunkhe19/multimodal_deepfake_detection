"""Image analysis pipeline: runs every check and builds one report.

    analyze_image(path)  ->  ImageAnalysis  ->  .to_dict()   (JSON-safe)

Signals used:
  1. trained classifier (face crop if a face is found, otherwise whole image)
  2. Error Level Analysis (JPEG only, heuristic baseline)
  3. metadata check (weak evidence)
If the trained model cannot be loaded, the pipeline still runs with signals 2
and 3 and says clearly that the result is inconclusive.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
from PIL import Image

from backend.config import settings
from modules.image_detection import scoring
from modules.image_detection.detector import get_classifier
from modules.image_detection.ela import compute_ela
from modules.image_detection.gradcam import compute_gradcam
from modules.image_detection.metadata import inspect_metadata
from utils.face_utils import crop_with_margin, detect_faces, face_detection_available
from utils.image_utils import load_rgb, ndarray_to_base64_png

logger = logging.getLogger(__name__)

MIN_FACE_CROP = 32  # pixels; smaller crops carry too little detail to score


@dataclass
class ImageAnalysis:
    result_label: str
    risk_score: float
    risk_level: str
    confidence: float
    explanation: str
    evidence: Dict[str, Any]
    limitations: List[str]
    model_used: bool
    ela_map: Optional[np.ndarray] = field(default=None, repr=False)
    heatmap: Optional[np.ndarray] = field(default=None, repr=False)

    def to_dict(self, include_images: bool = True) -> dict:
        data = {
            "modality": "image",
            "result_label": self.result_label,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "confidence": self.confidence,
            "p_fake": self.evidence.get("classifier", {}).get("p_fake"),
            "explanation": self.explanation,
            "evidence": self.evidence,
            "limitations": self.limitations,
            "model_used": self.model_used,
            "usable": self.model_used,   # the fusion engine ignores modules that are not usable
        }
        if include_images:
            data["images"] = {
                "ela_map_png_b64": ndarray_to_base64_png(self.ela_map) if self.ela_map is not None else None,
                "heatmap_png_b64": ndarray_to_base64_png(self.heatmap) if self.heatmap is not None else None,
            }
        return data


def _label_for(level: str, model_used: bool) -> str:
    if not model_used:
        return "Inconclusive (trained model not available)"
    return {
        "High": "Likely AI-generated or manipulated",
        "Medium": "Uncertain - possible manipulation",
        "Low": "No strong signs of manipulation detected",
    }[level]


def analyze_image(
    path: Union[str, Path],
    classifier: Any = "auto",
    want_heatmap: bool = True,
) -> ImageAnalysis:
    """Analyse one image file.

    classifier: "auto"  -> load the configured Hugging Face model (cached)
                None    -> skip the trained model (baseline checks only)
                object  -> any object with .predict(PIL image) -> ClassifierOutput
    """
    path = Path(path)
    limitations: List[str] = []

    pil = load_rgb(path)
    arr = np.asarray(pil)
    height, width = arr.shape[:2]

    meta = inspect_metadata(path)
    ela = compute_ela(path)

    # ---- trained classifier ----
    clf, clf_error = None, None
    if isinstance(classifier, str) and classifier == "auto":
        clf, clf_error = get_classifier()
    elif classifier is None:
        clf_error = "The trained classifier was turned off for this run."
    else:
        clf = classifier

    face_detector_ok = face_detection_available()
    faces = detect_faces(arr) if face_detector_ok else []
    classifier_ev: Dict[str, Any] = {"available": False}
    p_primary: Optional[float] = None
    heatmap = None
    scored_img = pil

    if clf is not None:
        try:
            whole = clf.predict(pil)
            primary, region = whole, "whole image"
            if faces:
                crop = crop_with_margin(arr, faces[0])
                if min(crop.shape[:2]) >= MIN_FACE_CROP:
                    scored_img = Image.fromarray(crop)
                    primary, region = clf.predict(scored_img), "largest detected face"
            p_primary = primary.p_fake
            classifier_ev = {
                "available": True,
                "model_id": getattr(clf, "model_id", "custom"),
                "region_scored": region,
                "p_fake": round(primary.p_fake, 4),
                "p_fake_whole_image": round(whole.p_fake, 4),
                "class_probabilities": {k: round(v, 4) for k, v in primary.probs.items()},
            }
            if want_heatmap and hasattr(clf, "fake_index"):
                heatmap, heat_note = compute_gradcam(clf, scored_img, clf.fake_index)
                if heat_note:
                    limitations.append(heat_note)
        except Exception as exc:
            logger.exception("Classifier failed")
            clf_error = f"The trained classifier failed on this image: {exc}"
            p_primary, classifier_ev = None, {"available": False}

    model_used = p_primary is not None
    if not model_used:
        classifier_ev["error"] = clf_error
        limitations.append(
            (clf_error or "No trained classifier was used.")
            + " Only the weak baseline checks (ELA, metadata) contributed, so treat this as inconclusive."
        )

    # ---- combine, categorise, explain ----
    combo = scoring.combine_signals(p_primary, ela.score if ela.applicable else None, meta)
    score = combo["risk_score"]
    if not model_used:
        # Weak heuristics alone must never produce a confident Low or High result.
        clamped = min(max(score, settings.risk_low_max), settings.risk_high_min)
        if clamped != score:
            limitations.append(
                "Without a trained model the risk score is limited to the Medium band, "
                "because ELA and metadata are weak evidence."
            )
        score = clamped
    level = scoring.risk_level(score)
    confidence = scoring.confidence_from(p_primary, width, height)

    if not ela.applicable:
        limitations.append(f"ELA not used: {ela.note}")
    if min(width, height) < 256:
        limitations.append("The image is small, so detectors have less detail to work with.")
    if not face_detector_ok:
        limitations.append("Face detection is unavailable on this system, so the whole image was scored.")
    elif not faces:
        limitations.append(
            "No face was detected, so the whole image was scored. Some detectors are trained mainly "
            "on face images and may be less reliable here."
        )
    limitations.append(
        "Detectors can be wrong, especially on images from generators newer than their training data, "
        "or after heavy compression or resizing. This is a risk estimate, not proof."
    )

    parts = []
    if model_used:
        pct = round(p_primary * 100)
        parts.append(f"The trained classifier rated the {classifier_ev['region_scored']} at {pct}% likelihood of being fake/AI-generated.")
    else:
        parts.append("No trained classifier was available for this run.")
    if ela.applicable:
        parts.append(f"ELA heuristic score {ela.score:.2f} (0-1; only a weak hint of uneven compression).")
    parts.extend(n for n in meta.notes if "Camera" not in n)
    explanation = " ".join(parts)

    return ImageAnalysis(
        result_label=_label_for(level, model_used),
        risk_score=score,
        risk_level=level,
        confidence=confidence,
        explanation=explanation,
        evidence={
            "classifier": classifier_ev,
            "ela": {
                "applicable": ela.applicable,
                "note": ela.note,
                "score": None if ela.score is None else round(ela.score, 4),
                "mean_error": None if ela.mean_error is None else round(ela.mean_error, 3),
            },
            "metadata": meta.to_dict(),
            "faces_detected": len(faces),
            "image_size": [width, height],
            "score_terms_logit": {k: round(v, 3) for k, v in combo["terms"].items()},
        },
        limitations=limitations,
        model_used=model_used,
        ela_map=ela.ela_map,
        heatmap=heatmap,
    )
