"""Command-line demo for the image module (no backend or UI needed).

    python -m modules.image_detection.run_demo --image path\\to\\photo.jpg
    python -m modules.image_detection.run_demo --image photo.jpg --no-model

Writes the ELA map and the Grad-CAM heatmap (when available) to reports/demo/.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from backend.config import settings
from modules.image_detection.analyzer import analyze_image
from utils.file_validation import ValidationError, validate_saved_file
from utils.image_utils import ndarray_to_png_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyse one image with the image module.")
    parser.add_argument("--image", required=True, help="Path to a JPG / JPEG / PNG file")
    parser.add_argument("--no-model", action="store_true", help="Skip the trained classifier (baseline checks only)")
    args = parser.parse_args()

    path = Path(args.image)
    if not path.is_file():
        print(f"File not found: {path}")
        return 1
    try:
        validate_saved_file(path, path.name, "image")
    except ValidationError as exc:
        print(f"Rejected: {exc}")
        return 1

    result = analyze_image(path, classifier=None if args.no_model else "auto")

    out_dir = settings.reports_dir / "demo"
    out_dir.mkdir(parents=True, exist_ok=True)
    if result.ela_map is not None:
        (out_dir / f"{path.stem}_ela.png").write_bytes(ndarray_to_png_bytes(result.ela_map))
    if result.heatmap is not None:
        (out_dir / f"{path.stem}_gradcam.png").write_bytes(ndarray_to_png_bytes(result.heatmap))

    print(json.dumps(result.to_dict(include_images=False), indent=2))
    print(f"\nImages saved in: {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
