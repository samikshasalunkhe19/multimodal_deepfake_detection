"""Pretrained image classifier (Hugging Face Transformers + PyTorch).

IMPORTANT HONESTY NOTES
  * This file only LOADS a model someone else trained. We do not claim its
    accuracy. Read the model card of whatever you set in IMAGE_MODEL_ID
    (license, training data, known limits) and evaluate it yourself with
    training/evaluate.py (Part 7).
  * Detectors trained on older generators often fail on newer ones.
    Always present the output as "risk", never as proof.

torch and transformers are imported lazily, so the rest of the project (and
the tests) still work when they are not installed.
"""
from __future__ import annotations

import logging
import re
import threading
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from backend.config import settings

logger = logging.getLogger(__name__)

FAKE_HINTS = {"fake", "ai", "artificial", "synthetic", "generated", "deepfake", "gan", "diffusion"}
REAL_HINTS = {"real", "human", "authentic", "genuine", "natural"}


@dataclass
class ClassifierOutput:
    p_fake: float                 # probability of the "fake / AI" class, 0..1
    probs: Dict[str, float]       # every class label -> probability
    predicted_label: str


def _tokens(label: str) -> set:
    return {t for t in re.split(r"[^a-z0-9]+", str(label).lower()) if t}


def resolve_fake_index(id2label: Dict[int, str], override: Optional[int] = None) -> int:
    """Work out which output index means 'fake', from the model's label names.

    Raises ValueError with clear instructions when the labels are ambiguous
    (for example LABEL_0 / LABEL_1), instead of silently guessing.
    """
    if override is not None:
        if override not in id2label:
            raise ValueError(f"FAKE_LABEL_INDEX={override} is not a valid class index {sorted(id2label)}.")
        return override

    fake = [i for i, name in id2label.items()
            if _tokens(name) & FAKE_HINTS and not _tokens(name) & REAL_HINTS]
    if len(fake) == 1:
        return fake[0]

    if len(id2label) == 2:
        real = [i for i, name in id2label.items() if _tokens(name) & REAL_HINTS]
        if len(real) == 1:
            return [i for i in id2label if i != real[0]][0]

    raise ValueError(
        f"Cannot tell which class means 'fake' from the labels {dict(id2label)}. "
        "Open the model card, then set the environment variable FAKE_LABEL_INDEX "
        "to the index of the fake / AI-generated class."
    )


class ImageClassifier:
    """Wraps a Hugging Face image-classification model."""

    def __init__(self, model_id: Optional[str] = None, fake_index: Optional[int] = None):
        import torch
        from transformers import AutoImageProcessor, AutoModelForImageClassification

        self.torch = torch
        self.model_id = model_id or settings.image_model_id
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info("Loading image model %s on %s", self.model_id, self.device)

        self.processor = AutoImageProcessor.from_pretrained(self.model_id)
        self.model = AutoModelForImageClassification.from_pretrained(self.model_id)
        self.model.to(self.device).eval()

        self.id2label = {int(k): str(v) for k, v in self.model.config.id2label.items()}
        override = fake_index if fake_index is not None else settings.fake_label_index
        self.fake_index = resolve_fake_index(self.id2label, override)

    def preprocess(self, pil_image):
        """PIL image -> normalised tensor on the model's device, shape (1, 3, H, W)."""
        batch = self.processor(images=pil_image, return_tensors="pt")
        return batch["pixel_values"].to(self.device)

    def predict(self, pil_image) -> ClassifierOutput:
        with self.torch.no_grad():
            logits = self.model(pixel_values=self.preprocess(pil_image)).logits
            probs = self.torch.softmax(logits, dim=-1)[0].cpu().tolist()
        best = max(range(len(probs)), key=probs.__getitem__)
        return ClassifierOutput(
            p_fake=float(probs[self.fake_index]),
            probs={self.id2label[i]: float(p) for i, p in enumerate(probs)},
            predicted_label=self.id2label[best],
        )


# ---- shared, lazily loaded instance ----------------------------------------

_lock = threading.Lock()
_cached: Optional[ImageClassifier] = None
_cached_error: Optional[str] = None
_attempted = False


def get_classifier() -> Tuple[Optional[ImageClassifier], Optional[str]]:
    """Load the model once and reuse it. Returns (classifier, error_message).

    A failure (missing packages, no internet for the first download, ambiguous
    labels) is remembered, so the app keeps working with the baseline checks
    and tells the user why the trained model was not used.
    """
    global _cached, _cached_error, _attempted
    with _lock:
        if _attempted:
            return _cached, _cached_error
        _attempted = True
        try:
            _cached = ImageClassifier()
        except ImportError as exc:
            _cached_error = (
                "PyTorch / Transformers are not installed, so the trained classifier was not used "
                f"({exc})."
            )
        except Exception as exc:  # network error, bad model id, ambiguous labels, ...
            _cached_error = f"The trained classifier could not be loaded: {exc}"
        if _cached_error:
            logger.warning(_cached_error)
        return _cached, _cached_error


def reset_classifier_cache() -> None:
    """Forget the cached model / error (used by tests and after config changes)."""
    global _cached, _cached_error, _attempted
    with _lock:
        _cached, _cached_error, _attempted = None, None, False
