"""Metadata inspection (EXIF, PNG text chunks, embedded tags).

This is WEAK evidence and the report says so:
  * Social-media apps strip EXIF from real photos, so "no EXIF" proves nothing.
  * Anyone can edit or remove metadata, so a clean file proves nothing either.
  * A tag that names an AI generator (e.g. a Stable Diffusion "parameters"
    text chunk) is much more telling, but only shows how the file was
    produced, not whether its content is misleading.

We do NOT parse C2PA "Content Credentials"; that needs a dedicated library.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import List, Optional, Union

from PIL import Image

# EXIF tag ids
_MAKE, _MODEL, _SOFTWARE = 0x010F, 0x0110, 0x0131

AI_KEYWORDS = (
    "stable diffusion", "stablediffusion", "midjourney", "dall-e", "dall·e", "dalle",
    "comfyui", "automatic1111", "invokeai", "novelai", "adobe firefly", "leonardo.ai",
    "sdxl", "trainedalgorithmicmedia",   # IPTC DigitalSourceType value for AI-generated media
)
EDITOR_KEYWORDS = (
    "photoshop", "gimp", "lightroom", "affinity", "pixlr", "paint.net",
    "snapseed", "canva", "picsart", "facetune",
)
_SCAN_BYTES = 256 * 1024   # headers live at the start of the file


@dataclass
class MetadataResult:
    format: Optional[str] = None
    has_exif: bool = False
    camera: Optional[str] = None
    software: Optional[str] = None
    ai_indicators: List[str] = field(default_factory=list)
    editing_software: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def _clean(value) -> Optional[str]:
    if value is None:
        return None
    text = value.decode("utf-8", "ignore") if isinstance(value, bytes) else str(value)
    text = text.replace("\x00", "").strip()
    return text[:200] or None


def inspect_metadata(path: Union[str, Path]) -> MetadataResult:
    result = MetadataResult()
    path = Path(path)

    with Image.open(path) as img:
        result.format = img.format
        exif = img.getexif()
        info_text = " ".join(
            f"{k} {v}" for k, v in (img.info or {}).items()
            if isinstance(v, (str, bytes)) and k not in ("icc_profile", "exif")
        )

    result.has_exif = len(exif) > 0
    make, model = _clean(exif.get(_MAKE)), _clean(exif.get(_MODEL))
    result.camera = " ".join(p for p in (make, model) if p) or None
    result.software = _clean(exif.get(_SOFTWARE))

    # Search EXIF software, PNG text chunks and the raw header bytes.
    with open(path, "rb") as fh:
        raw = fh.read(_SCAN_BYTES).decode("latin-1").lower()
    haystack = f"{result.software or ''} {info_text} {raw}".lower()

    result.ai_indicators = sorted({k for k in AI_KEYWORDS if k in haystack})
    result.editing_software = sorted({k for k in EDITOR_KEYWORDS if k in haystack})

    if result.format == "JPEG" and not result.has_exif:
        result.notes.append(
            "No EXIF data. Many apps and websites strip it, so this alone is not suspicious."
        )
    if result.camera:
        result.notes.append(f"Camera information present: {result.camera}.")
    if result.ai_indicators:
        result.notes.append(
            "Metadata mentions an AI image tool: " + ", ".join(result.ai_indicators) + "."
        )
    if result.editing_software:
        result.notes.append(
            "Metadata mentions editing software: " + ", ".join(result.editing_software)
            + ". Editing is common and not wrongdoing by itself."
        )
    return result
