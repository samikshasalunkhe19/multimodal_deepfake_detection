"""Fusion engine: combine per-modality results into ONE authenticity / risk score.

    fuse({"image": img_dict, "video": video_dict})  ->  dict (JSON-safe)

Method (documented priors chosen by us, not fitted on data)
  1. Only modules with usable=True count. A module without a trained model, or
     with too little evidence, is listed as "skipped" with the reason.
  2. Each usable module gives a log-odds value z_i = logit(risk_score / 100).
  3. Weighted mean:   z_mean = sum(w_i * z_i) / sum(w_i)       (weights in config.py)
  4. Strongest hint:  z_max  = max(z_i)
     Why blend both? A video with a real voice but a face-swapped picture would be
     diluted by a plain average (same reasoning as the video aggregator).
         z = 0.5 * z_mean + 0.5 * z_max
  5. Corroboration: if two or more modules independently reach High risk, add
     CORROBORATION_BONUS, because independent agreement is stronger evidence.
  6. Conflict: if one module says High and another says Low, the result is
     flagged "conflicting evidence", the bonus is not given and confidence drops.

The output is a risk estimate for a human to review, never proof.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.config import settings
from modules.image_detection import scoring

CORROBORATION_BONUS = 0.4
CONFLICT_CONFIDENCE_FACTOR = 0.6
MODALITIES = ("image", "video")

_LABELS = {
    "High": "Likely manipulated or AI-generated content",
    "Medium": "Uncertain - needs human review",
    "Low": "No strong signs of manipulation detected",
}


def _weight(modality: str) -> float:
    return {
        "image": settings.fusion_weight_image,
        "video": settings.fusion_weight_video,
    }.get(modality, 1.0)


def _skip_reason(result: dict) -> str:
    for lim in result.get("limitations", []):
        if "not used as evidence" in lim or "inconclusive" in lim.lower() or "needed" in lim:
            return lim
    return result.get("result_label", "Not enough evidence.")


def fuse(results: Dict[str, dict]) -> dict:
    unknown = [k for k in results if k not in MODALITIES]
    if unknown:
        raise ValueError(f"Unknown modalities: {unknown}")
    if not results:
        raise ValueError("Nothing to fuse: provide at least one module result.")

    used: List[dict] = []
    skipped: List[dict] = []
    limitations: List[str] = []
    for modality in MODALITIES:
        res = results.get(modality)
        if res is None:
            continue
        for lim in res.get("limitations", []):
            if lim not in limitations:
                limitations.append(lim)
        if res.get("usable", True) and res.get("risk_score") is not None:
            used.append({
                "modality": modality,
                "risk_score": float(res["risk_score"]),
                "risk_level": res.get("risk_level"),
                "confidence": float(res.get("confidence") or 0.0),
                "weight": _weight(modality),
                "z": scoring.logit(float(res["risk_score"]) / 100.0),
            })
        else:
            skipped.append({"modality": modality, "reason": _skip_reason(res)})

    fusion_note = (
        "Combined with a weighted log-odds blend of the average and the strongest module "
        "(see modules/fusion/engine.py). Weights are documented priors, not fitted on data."
    )
    limitations.append(
        "The combined score is a risk estimate to help a human decide what to check next. It is not proof "
        "that content is real or fake."
    )

    if not used:
        return {
            "modality": "overall",
            "result_label": "Inconclusive (no module produced usable evidence)",
            "risk_score": 50.0,
            "risk_level": "Medium",
            "confidence": 0.0,
            "explanation": "None of the submitted items could be scored reliably. "
                           + " ".join(f"{s['modality'].capitalize()}: {s['reason']}" for s in skipped),
            "evidence": {"modules_used": [], "modules_skipped": skipped, "conflict": False, "method": fusion_note},
            "limitations": limitations,
            "usable": False,
        }

    total_w = sum(m["weight"] for m in used)
    z_mean = sum(m["weight"] * m["z"] for m in used) / total_w
    z_max = max(m["z"] for m in used)
    z = 0.5 * z_mean + 0.5 * z_max

    high = [m for m in used if m["risk_score"] > settings.risk_high_min]
    low = [m for m in used if m["risk_score"] < settings.risk_low_max]
    conflict = bool(high and low)
    corroborated = len(high) >= 2 and not conflict
    if corroborated:
        z += CORROBORATION_BONUS

    score = round(100.0 * scoring.sigmoid(z), 1)
    level = scoring.risk_level(score)

    conf = sum(m["weight"] * m["confidence"] for m in used) / total_w
    if conflict:
        conf *= CONFLICT_CONFIDENCE_FACTOR
    if len(used) == 1:
        conf *= 0.85                      # a single modality cannot be cross-checked
    conf = round(min(max(conf, 0.0), 1.0), 3)

    # ---- explanation ----
    ordered = sorted(used, key=lambda m: m["risk_score"], reverse=True)
    parts = [
        "Strongest signal: " + f"{ordered[0]['modality']} ({ordered[0]['risk_score']:.0f}/100)."
    ]
    if len(used) > 1:
        parts.append("All modules: " + ", ".join(f"{m['modality']} {m['risk_score']:.0f}" for m in ordered) + ".")
    if corroborated:
        parts.append("Several independent modules agree on high risk, which strengthens the result.")
    if conflict:
        parts.append(
            "The modules disagree (one shows high risk, another low risk), so the evidence is conflicting "
            "and a human should review the original material."
        )
    if skipped:
        parts.append("Not used as evidence: " + "; ".join(s["modality"] for s in skipped) + ".")
    if len(used) == 1:
        parts.append("Only one modality was usable, so the result could not be cross-checked.")

    return {
        "modality": "overall",
        "result_label": "Conflicting evidence - needs human review" if conflict else _LABELS[level],
        "risk_score": score,
        "risk_level": level,
        "confidence": conf,
        "explanation": " ".join(parts),
        "evidence": {
            "modules_used": [
                {k: (round(v, 3) if isinstance(v, float) else v) for k, v in m.items()} for m in used
            ],
            "modules_skipped": skipped,
            "z_weighted_mean": round(z_mean, 3),
            "z_max": round(z_max, 3),
            "corroboration_bonus_applied": corroborated,
            "conflict": conflict,
            "method": fusion_note,
        },
        "limitations": limitations,
        "usable": True,
    }
