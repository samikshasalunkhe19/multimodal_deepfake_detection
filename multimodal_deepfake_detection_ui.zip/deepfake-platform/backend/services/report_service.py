"""Build a downloadable PDF report from a stored analysis record."""
from __future__ import annotations

import io
from typing import Any, Dict, List
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

_LEVEL_COLORS = {"Low": "#1a7f37", "Medium": "#b7791f", "High": "#c0392b"}
DISCLAIMER = (
    "This report is an automated risk estimate produced by statistical models and simple heuristics. "
    "It is not proof that content is real or fake. Detectors can be wrong, especially on new generation "
    "methods, compressed files and content unlike their training data. Use it to decide what to verify "
    "next, not as a final verdict."
)


def _p(text: Any, style) -> Paragraph:
    # Standard PDF fonts only cover Latin-1; replace other characters instead of crashing.
    safe = str(text).encode("latin-1", "replace").decode("latin-1")
    return Paragraph(escape(safe), style)


def _module_rows(record: dict) -> List[list]:
    details = record.get("details", {})
    if record["file_type"] == "overall":
        ev = details.get("fusion", {}).get("evidence", {})
        rows = [["Module", "Risk score", "Level", "Weight"]]
        for m in ev.get("modules_used", []):
            rows.append([m["modality"].capitalize(), f"{m['risk_score']:.0f}/100", m.get("risk_level", ""), m["weight"]])
        for s in ev.get("modules_skipped", []):
            rows.append([s["modality"].capitalize(), "not used", "-", "-"])
        return rows if len(rows) > 1 else []
    return []


def _limitations(record: dict) -> List[str]:
    d = record.get("details", {})
    if record["file_type"] == "overall":
        return d.get("fusion", {}).get("limitations", [])
    return d.get("limitations", [])


def build_report_pdf(record: Dict[str, Any]) -> bytes:
    """record: the dict from Analysis.to_dict()."""
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Title"], fontSize=20, spaceAfter=6)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], spaceBefore=10, spaceAfter=4)
    body = ParagraphStyle("body", parent=styles["BodyText"], fontSize=10, leading=14)
    small = ParagraphStyle("small", parent=body, fontSize=8.5, leading=11, textColor=colors.HexColor("#555555"))
    big = ParagraphStyle("big", parent=body, fontSize=30, leading=34, alignment=1)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=16 * mm, bottomMargin=16 * mm,
                            title="Authenticity analysis report")
    level = record["risk_level"]
    color = _LEVEL_COLORS.get(level, "#333333")

    story: list = [_p("Authenticity Analysis Report", h1)]
    meta = [
        ["Report ID", record["id"]],
        ["Created (UTC)", record["created_at"]],
        ["Input", record["file_name"]],
        ["Type", record["file_type"]],
    ]
    t = Table([[_p(a, small), _p(b, body)] for a, b in meta], colWidths=[32 * mm, 140 * mm])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    story += [t, Spacer(1, 8)]

    score_style = ParagraphStyle("score", parent=big, textColor=colors.HexColor(color))
    story.append(Paragraph(f"{record['risk_score']:.0f} / 100", score_style))
    story.append(Paragraph(f"<b>{escape(level)} risk</b> - {escape(str(record['result_label']))}",
                           ParagraphStyle("lvl", parent=body, alignment=1, fontSize=12)))
    conf = record.get("confidence")
    if conf is not None:
        story.append(Paragraph(f"Evidence strength: {conf * 100:.0f}% (not a calibrated probability)",
                               ParagraphStyle("conf", parent=small, alignment=1)))

    story += [_p("Explanation", h2), _p(record.get("explanation") or "-", body)]

    rows = _module_rows(record)
    if rows:
        story.append(_p("Module results", h2))
        tbl = Table([[_p(c, body) for c in r] for r in rows], colWidths=[50 * mm, 40 * mm, 35 * mm, 30 * mm])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eeeeee")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bbbbbb")),
        ]))
        story.append(tbl)

    lims = _limitations(record)
    if lims:
        story.append(_p("Limitations", h2))
        for lim in lims:
            story.append(_p("- " + lim, body))

    story += [Spacer(1, 10), _p("Important", h2), _p(DISCLAIMER, small)]
    doc.build(story)
    return buf.getvalue()
