"""Glue between the API and the detection modules.

Every function here:  validate/save upload -> analyse -> delete upload -> store the RESULT.
Only results are stored in the database. Uploaded files are never kept.
"""
from __future__ import annotations

from typing import BinaryIO, Dict, Optional

from sqlalchemy.orm import Session

from database import crud
from modules.fusion.engine import fuse
from modules.image_detection.analyzer import analyze_image
from modules.video_detection.analyzer import analyze_video
from utils.file_validation import ValidationError
from utils.temp_files import secure_upload

_FILE_ANALYZERS = {"image": analyze_image, "video": analyze_video}


def _store(db: Session, file_type: str, file_name: str, result: dict, details: Optional[dict] = None):
    return crud.create_analysis(
        db,
        file_type=file_type,
        file_name=file_name,
        result_label=str(result["result_label"])[:64],
        risk_score=result["risk_score"],
        risk_level=result["risk_level"],
        confidence=result.get("confidence"),
        explanation=result.get("explanation", ""),
        details=details if details is not None else result,
    )


def _with_record(record, payload: dict) -> dict:
    return {"id": record.id, "created_at": record.created_at.isoformat() + "Z",
            "file_name": record.file_name, **payload}


def _run_file(kind: str, stream: BinaryIO, filename: str):
    """Returns (analysis_object, safe_name). The temp file is deleted before this returns."""
    with secure_upload(stream, filename, kind) as vf:
        analysis = _FILE_ANALYZERS[kind](vf.path)
        return analysis, vf.safe_name


def analyze_file_upload(db: Session, kind: str, stream: BinaryIO, filename: str) -> dict:
    analysis, safe_name = _run_file(kind, stream, filename)
    record = _store(db, kind, safe_name, analysis.to_dict(include_images=False))
    return _with_record(record, analysis.to_dict(include_images=True))


def analyze_multimodal(db: Session, files: Dict[str, Optional[tuple]]) -> dict:
    """Analyse the image and/or video, fuse the results, store ONE 'overall' record."""
    full: Dict[str, dict] = {}
    stored: Dict[str, dict] = {}
    names = []
    for kind, item in files.items():
        if not item:
            continue
        stream, filename = item
        try:
            analysis, safe_name = _run_file(kind, stream, filename)
        except ValidationError as exc:
            raise ValidationError(f"{kind.capitalize()}: {exc}")
        full[kind] = analysis.to_dict(include_images=True)
        stored[kind] = analysis.to_dict(include_images=False)
        names.append(safe_name)

    if not full:
        raise ValidationError("Please provide an image, a video, or both.")

    fused = fuse(full)
    record = _store(db, "overall", ", ".join(names)[:255], fused, details={"fusion": fused, "components": stored})
    return _with_record(record, {**fused, "components": full})
