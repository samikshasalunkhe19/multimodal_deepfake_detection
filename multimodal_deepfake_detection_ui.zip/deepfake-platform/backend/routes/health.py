"""GET /api/health - quick status, without loading any heavy model."""
from __future__ import annotations

from fastapi import APIRouter

from backend.config import settings
from utils.face_utils import face_detection_available

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {
        "status": "ok",
        "face_detection": face_detection_available(),
        "models": {"image": {"model_id": settings.image_model_id}},
        "limits": {
            "max_image_mb": settings.max_image_bytes // (1024 * 1024),
            "max_video_mb": settings.max_video_bytes // (1024 * 1024),
        },
    }
