"""History endpoints: list, read, delete, and download a PDF report."""
from __future__ import annotations

from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session

from backend.services.report_service import build_report_pdf
from database import crud
from database.session import get_db

router = APIRouter(prefix="/history", tags=["history"])


@router.get("")
def list_history(
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    file_type: Optional[Literal["image", "video", "overall"]] = None,
    db: Session = Depends(get_db),
):
    items = crud.list_analyses(db, limit=limit, offset=offset, file_type=file_type)
    return {"total": crud.count_analyses(db, file_type), "items": [i.to_dict() for i in items]}


@router.get("/{analysis_id}")
def get_history_item(analysis_id: str, db: Session = Depends(get_db)):
    record = crud.get_analysis(db, analysis_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Analysis not found.")
    return record.to_dict()


@router.delete("/{analysis_id}")
def delete_history_item(analysis_id: str, db: Session = Depends(get_db)):
    if not crud.delete_analysis(db, analysis_id):
        raise HTTPException(status_code=404, detail="Analysis not found.")
    return {"deleted": analysis_id}


@router.get("/{analysis_id}/report.pdf")
def download_report(analysis_id: str, db: Session = Depends(get_db)):
    record = crud.get_analysis(db, analysis_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Analysis not found.")
    pdf = build_report_pdf(record.to_dict())
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="report_{analysis_id[:8]}.pdf"'},
    )
