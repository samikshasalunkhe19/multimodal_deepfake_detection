"""Analysis endpoints: POST /api/analyze/{image|video|multimodal}."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, File, UploadFile
from sqlalchemy.orm import Session

from backend.services import analysis_service as svc
from database.session import get_db

router = APIRouter(prefix="/analyze", tags=["analyze"])

# Routes are plain `def` (not async) on purpose: analysis is CPU-heavy, and FastAPI
# runs sync routes in a worker thread so the server stays responsive.


@router.post("/image")
def analyze_image_route(file: UploadFile = File(...), db: Session = Depends(get_db)):
    return svc.analyze_file_upload(db, "image", file.file, file.filename or "upload")


@router.post("/video")
def analyze_video_route(file: UploadFile = File(...), db: Session = Depends(get_db)):
    return svc.analyze_file_upload(db, "video", file.file, file.filename or "upload")


@router.post("/multimodal")
def analyze_multimodal_route(
    image: Optional[UploadFile] = File(None),
    video: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
):
    files = {
        kind: ((up.file, up.filename or "upload") if up is not None and up.filename else None)
        for kind, up in (("image", image), ("video", video))
    }
    return svc.analyze_multimodal(db, files)
