# Installation guide

Python 3.10 - 3.12. Commands are for Windows PowerShell; Linux/macOS: `source .venv/bin/activate`.

```powershell
cd deepfake-platform
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip

# 1. PyTorch FIRST (CPU build). Install order matters on Windows.
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# 2. everything else
pip install -r requirements.txt

# 3. (optional) settings, see .env.example
copy .env.example .env

# 4. tests (use stand-in models: no download, no internet)
python -m pytest

# 5. run, in two terminals
uvicorn backend.main:app --port 8000        # http://127.0.0.1:8000/docs
streamlit run frontend/app.py                # http://localhost:8501
```

The first image or video analysis downloads the Hugging Face image model (internet needed, once).

## Measuring accuracy

```powershell
python -m training.evaluate --modality image --data dataset\image    # needs dataset\image\real and \fake
python -m training.evaluate --modality video --data dataset\video --max-per-class 100
```

## Troubleshooting

| Problem | Fix |
|---|---|
| "Cannot reach the backend" | Start `uvicorn` first; if you changed the port set `$env:API_URL = "http://127.0.0.1:9000/api"`. |
| "PyTorch / Transformers are not installed" | Do step 1, then step 2 again. |
| Face detection shows a cross | `pip install --force-reinstall opencv-python`. Without it whole images/frames are scored. |
| "Cannot tell which class means 'fake'" | Read the model card, then set `FAKE_LABEL_INDEX`. |
| Upload over 100 MB refused | Raise `MAX_VIDEO_MB` in `.env` and `maxUploadSize` in `.streamlit/config.toml`. |
