import io

import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

from backend.main import app
from database.models import Base
from database.session import get_db, make_session_factory


@pytest.fixture
def client():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    factory = make_session_factory(engine)

    def override():
        db = factory()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override
    yield TestClient(app)
    app.dependency_overrides.clear()


def png_bytes(size=(96, 96)):
    rng = np.random.default_rng(0)
    buf = io.BytesIO()
    Image.fromarray(rng.integers(0, 256, (size[1], size[0], 3), dtype=np.uint8)).save(buf, format="PNG")
    return buf.getvalue()


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"
    assert "limits" in r.json() and "face_detection" in r.json()


def test_image_upload_returns_result_and_is_stored(client, fake_models):
    fake_models(0.9)
    r = client.post("/api/analyze/image", files={"file": ("photo.png", png_bytes(), "image/png")})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["modality"] == "image" and body["risk_level"] == "High" and body["id"]
    assert "images" in body                                    # ELA / heat-map for the UI

    hist = client.get("/api/history").json()
    assert hist["total"] == 1 and hist["items"][0]["id"] == body["id"]
    assert "images" not in hist["items"][0]["details"]         # big base64 images are not stored
    assert client.get(f"/api/history/{body['id']}").status_code == 200


def test_image_without_model_is_inconclusive(client):
    r = client.post("/api/analyze/image", files={"file": ("photo.png", png_bytes(), "image/png")})
    assert r.status_code == 200
    assert r.json()["usable"] is False and r.json()["risk_level"] == "Medium"


def test_unsupported_extension_rejected(client):
    r = client.post("/api/analyze/image", files={"file": ("x.gif", b"GIF89a", "image/gif")})
    assert r.status_code == 400 and "Unsupported" in r.json()["detail"]


def test_renamed_executable_rejected(client):
    r = client.post("/api/analyze/image", files={"file": ("x.png", b"MZ\x90\x00" + b"\0" * 50, "image/png")})
    assert r.status_code == 400 and "does not match" in r.json()["detail"]


def test_audio_endpoint_no_longer_exists(client):
    assert client.post("/api/analyze/audio", files={"file": ("x.wav", b"RIFF", "audio/wav")}).status_code == 404


def test_image_sent_to_video_endpoint_rejected(client):
    r = client.post("/api/analyze/video", files={"file": ("x.png", png_bytes(), "image/png")})
    assert r.status_code == 400


def make_avi(n=12):
    import os, tempfile, cv2
    fd, path = tempfile.mkstemp(suffix=".avi"); os.close(fd)
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"MJPG"), 10, (96, 96))
    if not w.isOpened():
        pytest.skip("This OpenCV build cannot write MJPG AVI files")
    for i in range(n):
        w.write(np.full((96, 96, 3), (i * 9) % 256, np.uint8))
    w.release()
    data = open(path, "rb").read(); os.unlink(path)
    return data


def test_video_upload(client, fake_models):
    fake_models(0.9)
    r = client.post("/api/analyze/video", files={"file": ("c.avi", make_avi(), "video/x-msvideo")})
    assert r.status_code == 200, r.text
    assert r.json()["modality"] == "video"


def test_multimodal_fuses_and_stores_one_overall_record(client, fake_models):
    fake_models(0.9)
    r = client.post("/api/analyze/multimodal", files={
        "image": ("p.png", png_bytes(), "image/png"), "video": ("c.avi", make_avi(), "video/x-msvideo")})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["modality"] == "overall" and set(body["components"]) == {"image", "video"}
    hist = client.get("/api/history").json()
    assert hist["total"] == 1 and hist["items"][0]["file_type"] == "overall"


def test_multimodal_with_nothing_is_rejected(client):
    r = client.post("/api/analyze/multimodal")
    assert r.status_code == 400 and "image, a video" in r.json()["detail"]


def test_multimodal_error_names_the_bad_input(client):
    r = client.post("/api/analyze/multimodal", files={"video": ("c.avi", b"RIFF" + b"\0" * 40, "video/x-msvideo")})
    assert r.status_code == 400 and r.json()["detail"].startswith("Video:")


def test_history_filter_delete_and_404(client, fake_models):
    fake_models(0.2)
    a = client.post("/api/analyze/image", files={"file": ("p.png", png_bytes(), "image/png")}).json()
    client.post("/api/analyze/video", files={"file": ("c.avi", make_avi(), "video/x-msvideo")})
    assert client.get("/api/history", params={"file_type": "image"}).json()["total"] == 1
    assert client.get("/api/history", params={"file_type": "bogus"}).status_code == 422
    assert client.delete(f"/api/history/{a['id']}").status_code == 200
    assert client.get(f"/api/history/{a['id']}").status_code == 404
    assert client.delete(f"/api/history/{a['id']}").status_code == 404


def test_pdf_report_for_single_and_overall(client, fake_models):
    fake_models(0.8)
    single = client.post("/api/analyze/image", files={"file": ("p.png", png_bytes(), "image/png")}).json()
    overall = client.post("/api/analyze/multimodal", files={
        "image": ("p.png", png_bytes(), "image/png"), "video": ("c.avi", make_avi(), "video/x-msvideo")}).json()
    for rec in (single, overall):
        r = client.get(f"/api/history/{rec['id']}/report.pdf")
        assert r.status_code == 200 and r.headers["content-type"] == "application/pdf"
        assert r.content.startswith(b"%PDF") and len(r.content) > 1500
    assert client.get("/api/history/nope/report.pdf").status_code == 404


def test_temp_files_are_cleaned_up(client, fake_models):
    from backend.config import settings
    fake_models(0.5)
    before = set(settings.temp_dir.glob("*")) if settings.temp_dir.exists() else set()
    client.post("/api/analyze/image", files={"file": ("p.png", png_bytes(), "image/png")})
    client.post("/api/analyze/image", files={"file": ("x.png", b"MZ" + b"\0" * 50, "image/png")})
    after = set(settings.temp_dir.glob("*")) if settings.temp_dir.exists() else set()
    assert after == before
