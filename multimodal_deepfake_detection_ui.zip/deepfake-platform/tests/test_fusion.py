import pytest

from modules.fusion.engine import fuse


def res(score, usable=True, conf=0.6, limitations=None):
    level = "Low" if score < 35 else "High" if score > 65 else "Medium"
    return {"risk_score": score, "risk_level": level, "confidence": conf, "usable": usable,
            "limitations": limitations or [], "result_label": "x"}


def test_agreeing_high_modules_get_bonus():
    r = fuse({"image": res(85), "video": res(80)})
    assert r["risk_level"] == "High" and r["evidence"]["corroboration_bonus_applied"]
    assert r["risk_score"] > 85


def test_conflict_is_flagged_and_lowers_confidence():
    agree = fuse({"image": res(85), "video": res(80)})
    clash = fuse({"image": res(85), "video": res(15)})
    assert clash["evidence"]["conflict"] and not clash["evidence"]["corroboration_bonus_applied"]
    assert "Conflicting" in clash["result_label"]
    assert clash["confidence"] < agree["confidence"]


def test_one_bad_module_is_not_diluted_away():
    r = fuse({"video": res(90), "image": res(30)})
    assert r["risk_score"] > 55            # plain average would be ~60 weighted, but strongest signal counts


def test_all_low_stays_low():
    r = fuse({"image": res(10), "video": res(15)})
    assert r["risk_level"] == "Low"


def test_unusable_modules_are_skipped_with_reason():
    skipped = res(50, usable=False, limitations=["No model. This module's result is not used as evidence."])
    r = fuse({"video": res(20), "image": skipped})
    assert [m["modality"] for m in r["evidence"]["modules_used"]] == ["video"]
    assert r["evidence"]["modules_skipped"][0]["modality"] == "image"
    assert "not used as evidence" in r["evidence"]["modules_skipped"][0]["reason"]
    assert "cross-checked" in r["explanation"]


def test_nothing_usable_is_inconclusive():
    r = fuse({"image": res(50, usable=False)})
    assert r["usable"] is False and r["risk_level"] == "Medium" and r["confidence"] == 0.0
    assert "Inconclusive" in r["result_label"]


def test_single_modality_confidence_is_reduced():
    assert fuse({"image": res(90, conf=0.8)})["confidence"] < 0.8


def test_output_is_valid_for_the_database():
    r = fuse({"image": res(70), "video": res(40)})
    assert 0 <= r["risk_score"] <= 100 and 0 <= r["confidence"] <= 1
    assert r["risk_level"] in ("Low", "Medium", "High") and len(r["result_label"]) <= 64


def test_bad_input_rejected():
    with pytest.raises(ValueError):
        fuse({})
    with pytest.raises(ValueError):
        fuse({"smell": res(50)})
