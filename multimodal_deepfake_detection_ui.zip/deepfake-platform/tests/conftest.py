"""Shared test setup: no test may download or load a real model."""
import pytest

from modules.image_detection.detector import ClassifierOutput


class FakeModel:
    """Stands in for any trained classifier (PIL image)."""
    model_id = "fake/model"

    def __init__(self, p_fake=0.9):
        self.p = p_fake

    def _out(self):
        return ClassifierOutput(self.p, {"fake": self.p, "real": 1 - self.p}, "fake" if self.p >= 0.5 else "real")

    def predict(self, *args):
        return self._out()


_ANALYZER_MODULES = (
    "modules.image_detection.analyzer",
    "modules.video_detection.analyzer",
)


def _patch(monkeypatch, value):
    import importlib
    for name in _ANALYZER_MODULES:
        monkeypatch.setattr(importlib.import_module(name), "get_classifier", lambda v=value: v)


@pytest.fixture(autouse=True)
def no_model_downloads(monkeypatch):
    _patch(monkeypatch, (None, "disabled in tests"))


@pytest.fixture
def fake_models(monkeypatch):
    """Make every module use a FakeModel. Call fake_models(0.2) to change the probability."""
    def _set(p_fake=0.9):
        _patch(monkeypatch, (FakeModel(p_fake), None))
        return p_fake
    return _set
