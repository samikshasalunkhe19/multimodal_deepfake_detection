import io
import json

import cv2
import numpy as np
import pytest

from modules.image_detection.detector import ClassifierOutput
from modules.video_detection.aggregator import aggregate_scores, video_confidence
from modules.video_detection.analyzer import analyze_video
from modules.video_detection.frame_extractor import (
    choose_frame_indices,
    format_timestamp,
    iter_sampled_frames,
    probe_video,
)
from utils.file_validation import ValidationError


# ---------- helpers ----------

def make_video(path, n_frames=40, fps=10, size=(160, 120)):
    """Write a small synthetic AVI. Each frame's brightness encodes its index."""
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"MJPG"), fps, size)
    if not writer.isOpened():
        pytest.skip("This OpenCV build cannot write MJPG AVI files")
    for i in range(n_frames):
        writer.write(np.full((size[1], size[0], 3), (i * 6) % 256, np.uint8))
    writer.release()
    return path


class SeqClassifier:
    """Returns the scripted probabilities in order, one per predict() call."""
    model_id = "fake/seq"

    def __init__(self, probs):
        self.probs = list(probs)
        self.calls = 0

    def predict(self, pil_image):
        p = self.probs[min(self.calls, len(self.probs) - 1)]
        self.calls += 1
        return ClassifierOutput(p, {"Real": 1 - p, "Fake": p}, "Fake" if p >= 0.5 else "Real")


def always_face(rgb):
    h, w = rgb.shape[:2]
    return [(w // 4, h // 4, w // 2, h // 2)]


# ---------- frame selection ----------

def test_choose_indices_one_per_second():
    assert choose_frame_indices(100, fps=10, target_fps=1, max_frames=60) == list(range(0, 100, 10))


def test_choose_indices_caps_and_spreads_evenly():
    idx = choose_frame_indices(10_000, fps=25, target_fps=1, max_frames=30)
    assert len(idx) <= 30 and idx[0] == 0
    assert idx[-1] > 9000                      # the end of the video is covered, not just the start
    assert idx == sorted(set(idx))


def test_choose_indices_handles_bad_input():
    assert choose_frame_indices(0, 25, 1, 10) == []
    assert choose_frame_indices(100, 0, 1, 10) == []


def test_format_timestamp():
    assert format_timestamp(12.34) == "0:12.3"
    assert format_timestamp(75.0) == "1:15.0"


# ---------- probing ----------

def test_probe_valid_video(tmp_path):
    info = probe_video(make_video(tmp_path / "a.avi", n_frames=40, fps=10))
    assert info.fps == 10 and info.frame_count == 40
    assert (info.width, info.height) == (160, 120)
    assert abs(info.duration_s - 4.0) < 0.01


def test_probe_rejects_garbage(tmp_path):
    bad = tmp_path / "x.avi"
    bad.write_bytes(b"RIFF\x00\x00\x00\x00AVI " + b"\x00" * 200)
    with pytest.raises(ValidationError):
        probe_video(bad)


def test_probe_rejects_too_long(tmp_path):
    with pytest.raises(ValidationError, match="too long"):
        probe_video(make_video(tmp_path / "a.avi", n_frames=40, fps=10), max_seconds=2)


def test_iter_frames_returns_requested_indices_in_order(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=40, fps=10)
    got = [i for i, _ in iter_sampled_frames(p, [0, 10, 25, 39])]
    assert got == [0, 10, 25, 39]


def test_iter_frames_stops_quietly_when_index_beyond_end(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=20, fps=10)
    got = [i for i, _ in iter_sampled_frames(p, [0, 5, 500])]
    assert got == [0, 5]


# ---------- aggregation ----------

def test_all_low_scores_give_low_video_score():
    agg = aggregate_scores(list(range(20)), [0.05] * 20)
    assert agg.video_p < 0.1 and agg.segments == [] and agg.longest_run == 0


def test_short_manipulated_segment_is_not_hidden_by_the_mean():
    probs = [0.05] * 16 + [0.95] * 4          # only 20% of frames are manipulated
    agg = aggregate_scores(list(range(20)), probs)
    assert agg.video_p > agg.mean_p            # top-k lifts it above the plain mean
    assert agg.video_p > 0.4
    assert len(agg.segments) == 1 and agg.segments[0].n_frames == 4
    assert agg.segments[0].start_s == 16 and agg.segments[0].end_s == 19


def test_single_spike_is_not_a_segment():
    probs = [0.05] * 9 + [0.99] + [0.05] * 10
    agg = aggregate_scores(list(range(20)), probs)
    assert agg.segments == [] and agg.longest_run == 1


def test_jitter_higher_for_flickering_scores():
    steady = aggregate_scores(list(range(10)), [0.6] * 10)
    flicker = aggregate_scores(list(range(10)), [0.1, 0.9] * 5)
    assert flicker.jitter > steady.jitter


def test_aggregate_input_validation():
    with pytest.raises(ValueError):
        aggregate_scores([], [])
    with pytest.raises(ValueError):
        aggregate_scores([1, 2], [0.5])


def test_confidence_drops_with_few_frames_and_jitter():
    assert video_confidence(0.95, 30, 0.0) > video_confidence(0.95, 3, 0.0)
    assert video_confidence(0.95, 30, 0.0) > video_confidence(0.95, 30, 0.8)
    assert video_confidence(0.5, 30, 0.0) == 0.0


# ---------- full pipeline ----------

def test_pipeline_high_risk(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)       # 10 s -> 10 frames
    r = analyze_video(p, classifier=SeqClassifier([0.95]), face_detector=always_face)
    assert r.usable and r.model_used
    assert r.risk_level == "High" and "Likely" in r.result_label
    assert r.evidence["frames_scored"] == 10
    assert r.top_frames[0]["timestamp"]
    assert len(r.timeline) == 10


def test_pipeline_finds_the_manipulated_segment_with_timestamps(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)       # frames at t = 0..9 s
    probs = [0.05] * 6 + [0.95] * 4                                # last 4 seconds manipulated
    r = analyze_video(p, classifier=SeqClassifier(probs), face_detector=always_face)
    seg = r.evidence["aggregate"]["segments"][0]
    assert seg["start_s"] == 6.0 and seg["end_s"] == 9.0
    assert r.top_frames[0]["timestamp_s"] >= 6.0


def test_pipeline_low_risk(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)
    r = analyze_video(p, classifier=SeqClassifier([0.02]), face_detector=always_face)
    assert r.risk_level == "Low" and r.usable


def test_pipeline_without_model_is_unusable_and_neutral(tmp_path):
    r = analyze_video(make_video(tmp_path / "a.avi"), classifier=None, face_detector=always_face)
    assert not r.usable and not r.model_used
    assert r.confidence == 0.0 and r.risk_score == 50.0
    assert "Inconclusive" in r.result_label


def test_pipeline_no_faces_is_unusable(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)
    r = analyze_video(p, classifier=SeqClassifier([0.9]), face_detector=lambda rgb: [])
    assert not r.usable
    assert r.evidence["frames_with_faces"] == 0
    assert any("faces" in l.lower() for l in r.limitations)


def test_pipeline_whole_frame_fallback_when_no_face_detector(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)
    r = analyze_video(p, classifier=SeqClassifier([0.9]), face_detector=None)
    assert r.usable and r.evidence["scoring_mode"] == "whole frames"
    assert any("Face detection is unavailable" in l for l in r.limitations)


def test_pipeline_survives_a_crashing_classifier(tmp_path):
    class Broken:
        def predict(self, img):
            raise RuntimeError("boom")
    r = analyze_video(make_video(tmp_path / "a.avi", n_frames=100, fps=10),
                      classifier=Broken(), face_detector=always_face)
    assert not r.usable
    assert any("could not be scored" in l for l in r.limitations)


def test_progress_callback_reaches_total(tmp_path):
    calls = []
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)
    analyze_video(p, classifier=SeqClassifier([0.5]), face_detector=always_face,
                  progress_cb=lambda d, t: calls.append((d, t)))
    assert calls and calls[-1] == (10, 10)
    assert [d for d, _ in calls] == sorted(d for d, _ in calls)


def test_to_dict_is_json_safe_and_images_optional(tmp_path):
    p = make_video(tmp_path / "a.avi", n_frames=100, fps=10)
    r = analyze_video(p, classifier=SeqClassifier([0.8]), face_detector=always_face)
    full = r.to_dict()
    json.dumps(full)
    assert full["suspicious_frames"][0]["thumbnail_png_b64"]
    slim = r.to_dict(include_images=False)
    assert "thumbnail_png_b64" not in slim["suspicious_frames"][0]
    assert "thumb" not in slim["suspicious_frames"][0]


def test_invalid_video_raises_validation_error(tmp_path):
    bad = tmp_path / "x.avi"
    bad.write_bytes(b"not a video at all")
    with pytest.raises(ValidationError):
        analyze_video(bad, classifier=None)
