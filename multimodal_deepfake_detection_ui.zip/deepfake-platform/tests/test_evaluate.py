import pytest

from tests.conftest import FakeModel
from training import evaluate


def test_collect_files_needs_both_folders(tmp_path):
    (tmp_path / "real").mkdir()
    with pytest.raises(FileNotFoundError):
        evaluate.collect_files(tmp_path, "image", None)
    (tmp_path / "fake").mkdir()
    (tmp_path / "real" / "a.png").write_bytes(b"x")
    (tmp_path / "fake" / "b.txt").write_bytes(b"x")
    assert evaluate.collect_files(tmp_path, "image", None) == [(tmp_path / "real" / "a.png", 0)]


def test_summary_with_scores():
    raw = {"y_true": [0, 0, 1, 1], "y_score": [10, 30, 80, 90], "unusable": 0, "rejected": 0, "total": 4}
    s = evaluate.summarise(raw)
    assert s["accuracy"] == 1.0 and s["roc_auc"] == 1.0 and "warning" in s


def test_unusable_results_are_reported_not_scored(tmp_path):
    from PIL import Image
    paths = []
    for name in ("real", "fake"):
        (tmp_path / name).mkdir()
        Image.new("RGB", (64, 64), "gray").save(tmp_path / name / "x.png")
    items = evaluate.collect_files(tmp_path, "image", None)
    s = evaluate.summarise(evaluate.score_items("image", items, classifier=None))
    assert s["scored"] == 0 and s["unusable"] == 2 and "accuracy" not in s
