"""Plain-language reasons are built only from evidence the detectors returned."""
from frontend.reasons import build_reasons
from frontend import theme

IMG = {"modality": "image", "risk_score": 82, "risk_level": "High", "result_label": "x", "evidence": {
    "classifier": {"available": True, "p_fake": 0.91, "region_scored": "largest detected face", "p_fake_whole_image": 0.4},
    "ela": {"applicable": True, "score": 0.7},
    "metadata": {"ai_indicators": ["midjourney"], "editing_software": [], "camera": None, "format": "PNG", "has_exif": False},
    "faces_detected": 1, "image_size": [200, 200]}}
VID = {"modality": "video", "evidence": {"frames_scored": 8, "frames_sampled": 10, "scoring_mode": "face crops", "aggregate": {
    "mean_p_fake": 0.5, "video_p_fake": 0.8, "fraction_suspicious": 0.4, "jitter": 0.2,
    "segments": [{"start_s": 3.0, "end_s": 7.0, "n_frames": 4, "max_p_fake": 0.9}]}}}


def test_image_reasons():
    titles = " | ".join(r["title"] for r in build_reasons(IMG))
    assert "91%" in titles and "AI image tool" in titles and "compression" in titles.lower()
    assert any(r["kind"] == "risk" for r in build_reasons(IMG))


def test_video_reasons_and_unusable():
    titles = " | ".join(r["title"] for r in build_reasons(VID))
    assert "suspicious segment" in titles and "0:03-0:07" in " ".join(r["detail"] for r in build_reasons(VID))
    assert build_reasons({"modality": "video", "evidence": {"frames_scored": 1}})[0]["title"] == "Not enough usable frames"


def test_overall_and_html_escaping():
    res = {"modality": "overall", "evidence": {"conflict": True, "modules_used": [
        {"modality": "image", "risk_score": 80, "risk_level": "High"}], "modules_skipped": []}, "components": {"image": IMG}}
    assert build_reasons(res)[0]["title"] == "Image and video disagree"
    html = theme.reasons_html([{"kind": "info", "title": "<script>", "detail": "a&b"}])
    assert "<script>" not in html and "&lt;script&gt;" in html
    assert "<svg" in theme.gauge_svg(100, "High") and "<svg" in theme.gauge_svg(0, "Low")
    assert build_reasons({"modality": "audio"}) == []
