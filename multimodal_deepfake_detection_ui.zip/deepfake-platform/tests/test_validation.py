import io
import os
import time

import pytest
from PIL import Image

from utils.file_validation import ValidationError, sanitize_filename, detect_signature
from utils.temp_files import cleanup_stale_files, save_upload, secure_upload


def make_png(size=(32, 32)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, (120, 40, 200)).save(buf, format="PNG")
    return buf.getvalue()


def make_jpeg(size=(32, 32)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, (10, 200, 50)).save(buf, format="JPEG")
    return buf.getvalue()


FAKE_MP4 = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64
FAKE_AVI = b"RIFF\x00\x00\x00\x00AVI LIST" + b"\x00" * 64


# ---------- filename cleaning ----------

def test_sanitize_removes_paths_and_odd_chars():
    assert sanitize_filename("../../etc/passwd.png") == "passwd.png"
    assert sanitize_filename("C:\\Users\\me\\photo (1).jpg") == "photo_1_.jpg"
    assert sanitize_filename("") == "upload"
    assert sanitize_filename(None) == "upload"
    assert len(sanitize_filename("a" * 500 + ".png")) <= 100


def test_detect_signature():
    assert detect_signature(make_png()[:16]) == "png"
    assert detect_signature(make_jpeg()[:16]) == "jpeg"
    assert detect_signature(FAKE_MP4[:16]) == "mp4_mov"
    assert detect_signature(FAKE_AVI[:16]) == "avi"
    assert detect_signature(b"MZ\x90\x00" + b"\x00" * 12) is None


# ---------- valid uploads ----------

@pytest.mark.parametrize("name,data", [("a.png", make_png()), ("a.JPG", make_jpeg()), ("a.jpeg", make_jpeg())])
def test_valid_images_accepted(tmp_path, name, data):
    with secure_upload(io.BytesIO(data), name, "image", temp_dir=tmp_path) as vf:
        assert vf.kind == "image"
        assert vf.path.exists()
        assert vf.size_bytes == len(data)


@pytest.mark.parametrize("name,data", [("c.mp4", FAKE_MP4), ("c.mov", FAKE_MP4), ("c.avi", FAKE_AVI)])
def test_valid_video_signatures_accepted(tmp_path, name, data):
    with secure_upload(io.BytesIO(data), name, "video", temp_dir=tmp_path) as vf:
        assert vf.kind == "video"


# ---------- rejected uploads ----------

def test_wrong_extension_rejected(tmp_path):
    with pytest.raises(ValidationError, match="Unsupported file type"):
        save_upload(io.BytesIO(b"x"), "notes.txt", "image", temp_dir=tmp_path)
    with pytest.raises(ValidationError):
        save_upload(io.BytesIO(b"x"), "clip.mp4", "image", temp_dir=tmp_path)


def test_executable_renamed_to_png_rejected(tmp_path):
    fake = b"MZ\x90\x00\x03" + b"\x00" * 200
    with pytest.raises(ValidationError, match="does not match"):
        with secure_upload(io.BytesIO(fake), "evil.png", "image", temp_dir=tmp_path):
            pass
    assert list(tmp_path.iterdir()) == []   # cleaned up even though it was rejected


def test_png_content_with_jpg_extension_rejected(tmp_path):
    with pytest.raises(ValidationError, match="does not match"):
        with secure_upload(io.BytesIO(make_png()), "x.jpg", "image", temp_dir=tmp_path):
            pass


def test_empty_file_rejected(tmp_path):
    with pytest.raises(ValidationError, match="empty"):
        with secure_upload(io.BytesIO(b""), "x.png", "image", temp_dir=tmp_path):
            pass


def test_oversized_file_rejected_and_partial_file_removed(tmp_path):
    with pytest.raises(ValidationError, match="too large"):
        save_upload(io.BytesIO(make_png((200, 200))), "x.png", "image", temp_dir=tmp_path, max_bytes=100)
    assert list(tmp_path.iterdir()) == []


def test_truncated_image_rejected(tmp_path):
    broken = make_png((64, 64))[:60]            # valid PNG header, data cut off
    with pytest.raises(ValidationError, match="valid image"):
        with secure_upload(io.BytesIO(broken), "x.png", "image", temp_dir=tmp_path):
            pass


def test_decompression_bomb_guard(tmp_path):
    with pytest.raises(ValidationError, match="too large"):
        with secure_upload(io.BytesIO(make_png((100, 100))), "x.png", "image",
                           temp_dir=tmp_path, max_pixels=50):
            pass


# ---------- temp file cleanup ----------

def test_temp_file_deleted_after_use(tmp_path):
    with secure_upload(io.BytesIO(make_png()), "x.png", "image", temp_dir=tmp_path) as vf:
        saved = vf.path
        assert saved.exists()
    assert not saved.exists()


def test_temp_file_deleted_even_if_analysis_crashes(tmp_path):
    saved = None
    with pytest.raises(RuntimeError):
        with secure_upload(io.BytesIO(make_png()), "x.png", "image", temp_dir=tmp_path) as vf:
            saved = vf.path
            raise RuntimeError("model crashed")
    assert saved is not None and not saved.exists()


def test_user_filename_never_used_on_disk(tmp_path):
    with secure_upload(io.BytesIO(make_png()), "../../secret.png", "image", temp_dir=tmp_path) as vf:
        assert "secret" not in vf.path.name
        assert vf.path.parent == tmp_path


def test_cleanup_stale_files(tmp_path):
    old = tmp_path / "old.bin"
    new = tmp_path / "new.bin"
    old.write_bytes(b"1")
    new.write_bytes(b"2")
    past = time.time() - 7200
    os.utime(old, (past, past))
    removed = cleanup_stale_files(max_age_seconds=3600, temp_dir=tmp_path)
    assert removed == 1
    assert not old.exists() and new.exists()
