"""Create small SYNTHETIC demo files in tests/sample_inputs/.

    python tests/make_samples.py

orig.jpg    - a smooth gradient saved once as JPEG (quality 75)
spliced.jpg - the same picture with a noisy square pasted in, then re-saved (quality 90)
sample.avi  - 10 seconds of a moving square (no faces)

They contain no faces and are not AI-generated. They only show how the reports
look and that the code runs; they say nothing about real-world accuracy.
For a meaningful test, use real photos and videos.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageFilter

out = Path(__file__).resolve().parent / "sample_inputs"
out.mkdir(exist_ok=True)

yy, xx = np.mgrid[0:384, 0:384]
base = np.stack([xx / 384 * 255, yy / 384 * 255, (xx + yy) / 768 * 255], axis=2).astype(np.uint8)
Image.fromarray(base).filter(ImageFilter.GaussianBlur(1)).save(out / "orig.jpg", quality=75)

img = Image.open(out / "orig.jpg").convert("RGB")
rng = np.random.default_rng(1)
img.paste(Image.fromarray(rng.integers(60, 200, (100, 100, 3), dtype=np.uint8)), (140, 140))
img.save(out / "spliced.jpg", quality=90)

print("Created:", out / "orig.jpg", "and", out / "spliced.jpg")

# A tiny synthetic video so the video demo has something to open.
video_path = out / "sample.avi"
writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"MJPG"), 10, (320, 240))
for i in range(100):                                   # 10 seconds at 10 fps
    frame = np.full((240, 320, 3), 40, np.uint8)
    x = 10 + i * 2
    cv2.rectangle(frame, (x, 80), (x + 60, 140), (200, 120, 60), -1)
    writer.write(frame)
writer.release()
print("Created:", video_path)

