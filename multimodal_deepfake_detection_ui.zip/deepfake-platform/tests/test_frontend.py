"""UI smoke test: runs the Streamlit script headlessly with the backend mocked."""
from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest   # noqa: E402

from frontend import api_client as api   # noqa: E402

APP = str(Path(__file__).resolve().parent.parent / "frontend" / "app.py")
RESULT = {
    "id": "abcd1234-0000-4000-8000-000000000000", "modality": "image", "result_label": "Uncertain - possible manipulation",
    "risk_score": 55.0, "risk_level": "Medium", "confidence": 0.4, "explanation": "Test result.",
    "evidence": {}, "limitations": ["Detectors can be wrong."], "usable": True, "images": {},
}
HEALTH = {"status": "ok", "face_detection": True, "models": {"image": {}}}


def test_app_loads_and_shows_history(monkeypatch):
    monkeypatch.setattr(api, "health", lambda: HEALTH)
    monkeypatch.setattr(api, "list_history", lambda **kw: {"total": 1, "items": [{
        "id": RESULT["id"], "file_type": "image", "file_name": "a.png", "created_at": "2026-11-25T10:00:00Z",
        "result_label": RESULT["result_label"], "risk_score": 55.0, "risk_level": "Medium", "details": RESULT}]})
    at = AppTest.from_file(APP, default_timeout=30).run()
    assert not at.exception
    assert len(at.tabs) == 3


def test_app_shows_error_when_backend_is_down(monkeypatch):
    def down(*a, **k):
        raise api.ApiError("Cannot reach the backend")
    monkeypatch.setattr(api, "health", down)
    monkeypatch.setattr(api, "list_history", down)
    at = AppTest.from_file(APP, default_timeout=30).run()
    assert not at.exception
    assert any("Cannot reach" in e.value for e in at.error)
