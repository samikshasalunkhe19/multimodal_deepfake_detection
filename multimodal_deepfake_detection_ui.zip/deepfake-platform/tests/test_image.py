import io

import numpy as np
import pytest
from PIL import Image, PngImagePlugin

from modules.image_detection import scoring
from modules.image_detection.analyzer import analyze_image
from modules.image_detection.detector import ClassifierOutput, resolve_fake_index
from modules.image_detection.ela import compute_ela
from modules.image_detection.metadata import inspect_metadata


# ---------- helpers ----------

def noisy_image(size=(256, 256), seed=0) -> Image.Image:
    rng = np.random.default_rng(seed)
    return Image.fromarray(rng.integers(0, 256, (size[1], size[0], 3), dtype=np.uint8))


def save_jpeg(path, img=None, exif_software=None, quality=85):
    img = img or noisy_image()
    kwargs = {"format": "JPEG", "quality": quality}
    if exif_software:
        exif = Image.Exif()
        exif[0x0131] = exif_software
        exif[0x010F] = "TestCam"
        kwargs["exif"] = exif
    img.save(path, **kwargs)
    return path


class FakeClassifier:
    """Stands in for the Hugging Face model so tests need no download or PyTorch."""
    model_id = "fake/model"

    def __init__(self, p_fake):
        self.p = p_fake

    def predict(self, pil_image):
        return ClassifierOutput(self.p, {"Real": 1 - self.p, "Fake": self.p},
                                "Fake" if self.p >= 0.5 else "Real")


# ---------- label resolution ----------

@pytest.mark.parametrize("labels,expected", [
    ({0: "Real", 1: "Fake"}, 1),
    ({0: "fake", 1: "real"}, 0),
    ({0: "human", 1: "artificial"}, 1),
    ({0: "AI-generated", 1: "Human-made"}, 0),
    ({0: "REAL", 1: "FAKE"}, 1),
])
def test_resolve_fake_index(labels, expected):
    assert resolve_fake_index(labels) == expected


def test_ambiguous_labels_raise_with_instructions():
    with pytest.raises(ValueError, match="FAKE_LABEL_INDEX"):
        resolve_fake_index({0: "LABEL_0", 1: "LABEL_1"})


def test_override_wins_and_is_validated():
    assert resolve_fake_index({0: "LABEL_0", 1: "LABEL_1"}, override=0) == 0
    with pytest.raises(ValueError):
        resolve_fake_index({0: "a", 1: "b"}, override=5)


# ---------- ELA ----------

def test_ela_on_jpeg(tmp_path):
    p = save_jpeg(tmp_path / "a.jpg")
    r = compute_ela(p)
    assert r.applicable
    assert 0.0 <= r.score <= 1.0
    assert r.ela_map.shape == (256, 256, 3) and r.ela_map.dtype == np.uint8


def test_ela_not_applicable_to_png(tmp_path):
    p = tmp_path / "a.png"
    noisy_image().save(p)
    r = compute_ela(p)
    assert not r.applicable and "JPEG" in r.note


def test_ela_skips_tiny_images(tmp_path):
    p = save_jpeg(tmp_path / "t.jpg", noisy_image((32, 32)))
    assert not compute_ela(p).applicable


# ---------- metadata ----------

def test_metadata_camera_and_editor(tmp_path):
    p = save_jpeg(tmp_path / "e.jpg", exif_software="Adobe Photoshop 25")
    m = inspect_metadata(p)
    assert m.has_exif and m.camera == "TestCam"
    assert "photoshop" in m.editing_software and not m.ai_indicators


def test_metadata_ai_png_text_chunk(tmp_path):
    p = tmp_path / "sd.png"
    info = PngImagePlugin.PngInfo()
    info.add_text("parameters", "a cat, Steps: 20, Sampler: Euler, Stable Diffusion")
    noisy_image().save(p, pnginfo=info)
    m = inspect_metadata(p)
    assert "stable diffusion" in m.ai_indicators


def test_missing_exif_on_jpeg_is_only_a_note(tmp_path):
    m = inspect_metadata(save_jpeg(tmp_path / "n.jpg"))
    assert not m.has_exif and any("No EXIF" in n for n in m.notes)


# ---------- scoring ----------

def test_score_increases_with_classifier_probability():
    meta = type("M", (), {"ai_indicators": [], "editing_software": [], "format": "PNG", "has_exif": False})()
    scores = [scoring.combine_signals(p, None, meta)["risk_score"] for p in (0.05, 0.3, 0.5, 0.8, 0.97)]
    assert scores == sorted(scores) and scores[0] < 10 and scores[-1] > 90


def test_ai_tag_raises_score_but_weak_signals_cannot_flip_a_confident_model():
    clean = type("M", (), {"ai_indicators": [], "editing_software": [], "format": "PNG", "has_exif": False})()
    tagged = type("M", (), {"ai_indicators": ["midjourney"], "editing_software": [], "format": "PNG", "has_exif": False})()
    assert scoring.combine_signals(0.5, None, tagged)["risk_score"] > scoring.combine_signals(0.5, None, clean)["risk_score"]
    # ELA at its maximum nudge must not turn a 2% "fake" into a high-risk result
    assert scoring.combine_signals(0.02, 1.0, clean)["risk_score"] < scoring.settings.risk_low_max


def test_risk_levels():
    assert scoring.risk_level(10) == "Low"
    assert scoring.risk_level(50) == "Medium"
    assert scoring.risk_level(90) == "High"


def test_confidence_is_lower_for_small_images_and_without_model():
    assert scoring.confidence_from(0.95, 512, 512) > scoring.confidence_from(0.95, 100, 100)
    assert scoring.confidence_from(None, 512, 512) == 0.1
    assert scoring.confidence_from(0.5, 512, 512) == 0.0


# ---------- full pipeline ----------

def test_pipeline_with_fake_classifier_high_and_low(tmp_path):
    p = save_jpeg(tmp_path / "x.jpg")
    high = analyze_image(p, classifier=FakeClassifier(0.97), want_heatmap=False)
    low = analyze_image(p, classifier=FakeClassifier(0.03), want_heatmap=False)
    assert high.model_used and high.risk_level == "High" and "Likely" in high.result_label
    assert low.risk_level == "Low"
    assert high.risk_score > low.risk_score
    assert 0 <= high.confidence <= 1


def test_pipeline_without_model_is_honest_about_it(tmp_path):
    r = analyze_image(save_jpeg(tmp_path / "x.jpg"), classifier=None)
    assert not r.model_used
    assert "Inconclusive" in r.result_label
    assert r.confidence == 0.1
    assert any("inconclusive" in l.lower() for l in r.limitations)


def test_without_model_score_is_limited_to_medium_band(tmp_path):
    p = tmp_path / "sd.png"
    info = PngImagePlugin.PngInfo()
    info.add_text("parameters", "Steps: 20, Stable Diffusion, midjourney")
    noisy_image().save(p, pnginfo=info)
    r = analyze_image(p, classifier=None)
    assert r.risk_level == "Medium" and 35 <= r.risk_score <= 65
    assert "Inconclusive" in r.result_label


def test_pipeline_survives_a_crashing_classifier(tmp_path):
    class Broken:
        def predict(self, img):
            raise RuntimeError("boom")
    r = analyze_image(save_jpeg(tmp_path / "x.jpg"), classifier=Broken(), want_heatmap=False)
    assert not r.model_used and "boom" in r.evidence["classifier"]["error"]


def test_to_dict_is_json_safe_and_images_optional(tmp_path):
    import json
    r = analyze_image(save_jpeg(tmp_path / "x.jpg"), classifier=FakeClassifier(0.6), want_heatmap=False)
    full = r.to_dict()
    json.dumps(full)                                     # must not raise
    assert full["usable"] is True
    assert full["images"]["ela_map_png_b64"]             # ELA map included for JPEG
    assert "images" not in r.to_dict(include_images=False)


def test_png_pipeline_skips_ela(tmp_path):
    p = tmp_path / "x.png"
    noisy_image().save(p)
    r = analyze_image(p, classifier=FakeClassifier(0.5), want_heatmap=False)
    assert r.evidence["ela"]["applicable"] is False and r.ela_map is None


def test_exif_rotated_image_does_not_crash(tmp_path):
    exif = Image.Exif()
    exif[0x0112] = 6                                     # "rotate 90" orientation flag
    p = tmp_path / "rot.jpg"
    noisy_image((300, 200)).save(p, format="JPEG", exif=exif)
    r = analyze_image(p, classifier=FakeClassifier(0.5), want_heatmap=False)
    assert r.evidence["image_size"] == [200, 300]        # rotated by the EXIF flag
