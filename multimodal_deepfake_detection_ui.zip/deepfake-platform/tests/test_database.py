import pytest

pytest.importorskip("sqlalchemy")   # skipped (not failed) if SQLAlchemy is not installed

from database import crud
from database.session import init_db, make_engine, make_session_factory, session_scope


@pytest.fixture()
def factory(tmp_path):
    engine = make_engine(f"sqlite:///{tmp_path / 'test.db'}")
    init_db(engine)
    yield make_session_factory(engine)
    engine.dispose()


def _make(db, name="a.png", score=42.0, level="Medium", ftype="image"):
    return crud.create_analysis(
        db, file_type=ftype, file_name=name, result_label="Possibly manipulated",
        risk_score=score, risk_level=level, confidence=0.7,
        explanation="test", details={"ela": 0.3},
    )


def test_create_and_get(factory):
    with session_scope(factory) as db:
        rec = _make(db)
        got = crud.get_analysis(db, rec.id)
        assert got.file_name == "a.png"
        assert got.to_dict()["details"] == {"ela": 0.3}
        assert len(rec.id) == 36


def test_list_newest_first_and_filter(factory):
    with session_scope(factory) as db:
        _make(db, "first.png")
        _make(db, "second.mp4", ftype="video")
        names = [r.file_name for r in crud.list_analyses(db)]
        assert names == ["second.mp4", "first.png"]
        assert [r.file_name for r in crud.list_analyses(db, file_type="image")] == ["first.png"]
        assert crud.count_analyses(db) == 2


def test_delete(factory):
    with session_scope(factory) as db:
        rec = _make(db)
        assert crud.delete_analysis(db, rec.id) is True
        assert crud.delete_analysis(db, rec.id) is False
        assert crud.count_analyses(db) == 0


@pytest.mark.parametrize("kwargs", [
    {"risk_score": 150}, {"risk_score": -1}, {"risk_level": "Severe"}, {"file_type": "audio"},
])
def test_invalid_values_rejected(factory, kwargs):
    base = dict(db=None, file_type="image", file_name="a.png", result_label="x",
                risk_score=10, risk_level="Low")
    base.update(kwargs)
    with session_scope(factory) as db:
        base["db"] = db
        with pytest.raises(ValueError):
            crud.create_analysis(**base)
